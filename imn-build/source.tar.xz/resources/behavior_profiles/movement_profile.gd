class_name LabMovementProfile
extends Resource
## PROVISIONAL_TEST_DESIGN: these values have not been measured from the N64 game.
@export var provenance: String = "PROVISIONAL_TEST_DESIGN_NOT_MEASURED"
@export var walk_speed: float = 3.0
@export var run_speed: float = 6.0
@export var acceleration: float = 20.0
@export var air_acceleration: float = 7.0
@export var deceleration: float = 24.0
@export var gravity: float = 18.0
@export var jump_speed: float = 6.0
@export var terminal_speed: float = 40.0
@export var landing_seconds: float = 0.1
@export var floor_snap: float = 0.18
@export var maximum_slope_degrees: float = 46.0
@export var camera_distance: float = 5.2
@export var camera_fov: float = 65.0

# Original laboratory traversal values; NOT measured from the N64 game.
@export var capsule_radius: float = 0.3
@export var standing_height: float = 1.7
@export var crouching_height: float = 1.0
@export var crouch_speed: float = 1.4
@export var step_height: float = 0.32
@export var ledge_reach_height: float = 1.15
@export var ledge_probe_height: float = 1.0
@export var ledge_reach: float = 0.85
@export var ledge_hang_offset: float = 1.35
@export var ledge_shimmy_speed: float = 1.2
@export var mantle_seconds: float = 0.55
@export var climb_speed: float = 1.7
@export var climb_attach_distance: float = 1.5
@export var climb_exit_distance: float = 1.2
@export var swim_speed: float = 2.4
@export var swim_vertical_speed: float = 1.7
@export var swim_acceleration: float = 6.0
@export var swim_surface_offset: float = 1.1
@export var water_ledge_reach_height: float = 0.8
@export var slide_acceleration: float = 9.0
@export var push_force: float = 45.0
@export var push_effective_mass: float = 15.0
