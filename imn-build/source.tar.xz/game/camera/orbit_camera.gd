class_name LabOrbitCamera
extends Node3D

var pitch: float = -0.2
var yaw: float = 0.0
var camera: Camera3D
var arm: SpringArm3D
var target: Node3D

func _ready() -> void:
	target = get_parent() as Node3D
	top_level = true
	physics_interpolation_mode = Node.PHYSICS_INTERPOLATION_MODE_OFF
	global_position = target.global_position + Vector3.UP * 1.25
	arm = SpringArm3D.new()
	arm.spring_length = 5.2
	arm.margin = 0.15
	add_child(arm)
	camera = Camera3D.new()
	camera.fov = 65.0
	camera.near = 0.1
	camera.current = true
	arm.add_child(camera)
	apply_angles()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look(event.relative * 0.0025)

func look(delta: Vector2) -> void:
	yaw -= delta.x
	pitch = clampf(pitch - delta.y, -1.1, 0.35)
	apply_angles()

func apply_angles() -> void:
	rotation = Vector3(pitch, yaw, 0.0)

func _process(delta: float) -> void:
	# Camera uses the interpolated fixed-tick target transform; look input is presentation only.
	global_position = target.get_global_transform_interpolated().origin + Vector3.UP * 1.25
	var stick := Input.get_vector(&"look_left", &"look_right", &"look_up", &"look_down")
	look(stick * delta * 1.8)
