class_name LabSaveStore
extends RefCounted

const SCHEMA: int = 1
const SAVE_PATH: String = "user://checkpoint_v1.json"
const MAX_BYTES: int = 4096

static func encode(position: Vector3, yaw: float, beacon: bool, progress: Dictionary = {}) -> Dictionary:
	var result := {"schema": SCHEMA, "position": [position.x, position.y, position.z], "yaw": yaw, "beacon": beacon}
	if not progress.is_empty():
		result["progress"] = progress.duplicate(true)
	return result

static func validate(data: Variant) -> bool:
	if not data is Dictionary or data.get("schema") != SCHEMA:
		return false
	var coordinates: Variant = data.get("position")
	if not coordinates is Array or coordinates.size() != 3:
		return false
	for number: Variant in coordinates:
		if not (number is float or number is int) or not is_finite(float(number)) or absf(float(number)) > 10000.0:
			return false
	var yaw: Variant = data.get("yaw")
	if not ((yaw is float or yaw is int) and is_finite(float(yaw)) and absf(float(yaw)) < 100000.0 and data.get("beacon") is bool):
		return false
	if not data.has("progress"):
		return true
	var progress: Variant = data["progress"]
	if not progress is Dictionary or progress.size() != 3:
		return false
	if not progress.get("gate_open") is bool:
		return false
	var counts: Variant = progress.get("inventory")
	if not counts is Dictionary or counts.size() > 32:
		return false
	for key: Variant in counts:
		if not key is String or key.is_empty() or key.length() > 64 or not key.is_valid_identifier():
			return false
		var amount: Variant = counts[key]
		# Godot JSON numbers round-trip as floats. Allow only whole, finite values.
		if not (amount is int or amount is float) or not is_finite(float(amount)):
			return false
		if float(amount) < 0.0 or float(amount) > 999.0 or float(amount) != floorf(float(amount)):
			return false
	var collected: Variant = progress.get("collected_pickups")
	if not collected is Array or collected.size() > 64:
		return false
	var unique: Dictionary = {}
	for key: Variant in collected:
		if not key is String or key.is_empty() or key.length() > 64 or not key.is_valid_identifier() or unique.has(key):
			return false
		unique[key] = true
	return true

static func write(data: Dictionary, path: String = SAVE_PATH) -> Error:
	if not validate(data):
		return ERR_INVALID_DATA
	var temporary := path + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return FileAccess.get_open_error()
	file.store_string(JSON.stringify(data))
	file.flush()
	file.close()
	return DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(path))

static func read(path: String = SAVE_PATH) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_BYTES:
		return {}
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		return {}
	var decoded: Variant = parser.data
	return decoded if validate(decoded) else {}
