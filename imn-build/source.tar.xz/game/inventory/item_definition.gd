class_name LabItemDefinition
extends Resource
## Synthetic prototype item. Not reconstructed from ROM data.

@export var item_id: StringName = &""
@export var display_name: String = ""
@export_range(1, 999) var max_stack: int = 1
