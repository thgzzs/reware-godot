class_name LabInventory
extends RefCounted
## Data-driven, bounded inventory with all-or-nothing transactions.
## Domain state is independent of input, rendering, and save file formats.

signal changed(item_id: StringName, count: int)

var _definitions: Dictionary = {}
var _quantities: Dictionary = {}

func register_item(definition: LabItemDefinition) -> bool:
	if definition == null or definition.item_id.is_empty() or definition.max_stack < 1 or definition.max_stack > 999:
		return false
	if _definitions.has(definition.item_id):
		return false
	_definitions[definition.item_id] = definition
	_quantities[definition.item_id] = 0
	return true

func quantity(item_id: StringName) -> int:
	return int(_quantities.get(item_id, 0))

func can_add(item_id: StringName, count: int = 1) -> bool:
	if not _definitions.has(item_id) or count <= 0:
		return false
	return quantity(item_id) + count <= (_definitions[item_id] as LabItemDefinition).max_stack

func add_item(item_id: StringName, count: int = 1) -> bool:
	if not can_add(item_id, count):
		return false
	_quantities[item_id] = quantity(item_id) + count
	changed.emit(item_id, quantity(item_id))
	return true

func can_remove(item_id: StringName, count: int = 1) -> bool:
	return _definitions.has(item_id) and count > 0 and quantity(item_id) >= count

func remove_item(item_id: StringName, count: int = 1) -> bool:
	if not can_remove(item_id, count):
		return false
	_quantities[item_id] = quantity(item_id) - count
	changed.emit(item_id, quantity(item_id))
	return true

func to_save_data() -> Dictionary:
	var result: Dictionary = {}
	for item_id: StringName in _quantities:
		result[String(item_id)] = int(_quantities[item_id])
	return result

func restore_save_data(saved: Variant) -> bool:
	# Validate the entire candidate before mutating any entry. Omitted keys are zero.
	if not saved is Dictionary or saved.size() > 32:
		return false
	for key: Variant in saved:
		if not key is String or not _definitions.has(StringName(key)):
			return false
		var amount: Variant = saved[key]
		# Godot JSON.parse converts integer literals to float; accept *only* finite
		# mathematical integers, never fractional/NaN/infinite quantities.
		if not (amount is int or amount is float) or not is_finite(float(amount)):
			return false
		if float(amount) < 0.0 or float(amount) > float((_definitions[StringName(key)] as LabItemDefinition).max_stack) or float(amount) != floorf(float(amount)):
			return false
	for item_id: StringName in _definitions:
		var next_count := int(saved.get(String(item_id), 0))
		if quantity(item_id) != next_count:
			_quantities[item_id] = next_count
			changed.emit(item_id, next_count)
	return true
