extends LabWorld

func _ready() -> void:
	var version := Engine.get_version_info()
	var supported := int(version.major) > 4 or (int(version.major) == 4 and (int(version.minor) > 7 or (int(version.minor) == 7 and int(version.patch) >= 2)))
	if not supported or str(version.status) != "stable":
		fail("Godot 4.7.2 stable or newer stable is required.")
		return
	if ProjectSettings.get_setting("physics/3d/physics_engine") != "Jolt Physics" or not ClassDB.class_exists("JoltPhysicsServer3D"):
		fail("Built-in Jolt Physics is required.")
		return
	if RenderingServer.get_current_rendering_method() != "forward_plus" or RenderingServer.get_rendering_device() == null:
		fail("Forward+ with a supported RenderingDevice is required. This device is unsupported; renderer fallback is disabled.")
		return
	var driver := RenderingServer.get_current_rendering_driver_name()
	if driver not in ["vulkan", "metal", "d3d12"]:
		fail("Unsupported RenderingDevice driver: " + driver)
		return
	print("NATIVE_LAB_START version=", version.string, " renderer=", RenderingServer.get_current_rendering_method(), " driver=", driver, " physics=Jolt Physics")
	super._ready()

func fail(reason: String) -> void:
	push_error(reason)
	OS.alert(reason, "Unsupported runtime")
	get_tree().quit(2)
