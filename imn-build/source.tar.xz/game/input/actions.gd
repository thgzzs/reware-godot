class_name LabActions
extends RefCounted

const ACTIONS: Array[StringName] = [&"move_left", &"move_right", &"move_forward", &"move_back", &"run", &"jump", &"crouch", &"traverse", &"interact", &"restore", &"presentation", &"look_left", &"look_right", &"look_up", &"look_down"]

static func install() -> void:
	for action in ACTIONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.18)
	key(&"move_left", KEY_A)
	key(&"move_right", KEY_D)
	key(&"move_forward", KEY_W)
	key(&"move_back", KEY_S)
	key(&"run", KEY_SHIFT)
	key(&"jump", KEY_SPACE)
	key(&"crouch", KEY_C)
	key(&"traverse", KEY_F)
	key(&"interact", KEY_E)
	key(&"restore", KEY_R)
	key(&"presentation", KEY_TAB)
	axis(&"move_left", JOY_AXIS_LEFT_X, -1.0)
	axis(&"move_right", JOY_AXIS_LEFT_X, 1.0)
	axis(&"move_forward", JOY_AXIS_LEFT_Y, -1.0)
	axis(&"move_back", JOY_AXIS_LEFT_Y, 1.0)
	axis(&"look_left", JOY_AXIS_RIGHT_X, -1.0)
	axis(&"look_right", JOY_AXIS_RIGHT_X, 1.0)
	axis(&"look_up", JOY_AXIS_RIGHT_Y, -1.0)
	axis(&"look_down", JOY_AXIS_RIGHT_Y, 1.0)
	button(&"run", JOY_BUTTON_LEFT_SHOULDER)
	button(&"jump", JOY_BUTTON_A)
	button(&"crouch", JOY_BUTTON_RIGHT_SHOULDER)
	button(&"traverse", JOY_BUTTON_B)
	button(&"interact", JOY_BUTTON_X)
	button(&"restore", JOY_BUTTON_Y)
	button(&"presentation", JOY_BUTTON_BACK)

static func key(action: StringName, physical_code: Key) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = physical_code
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)

static func axis(action: StringName, index: JoyAxis, value: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.device = -1
	event.axis = index
	event.axis_value = value
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)

static func button(action: StringName, index: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.device = -1
	event.button_index = index
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)
