class_name LabPickup
extends Area3D
## Explicit-use pickup fixture, entirely original and provisional.

@export var pickup_id: String = ""
@export var item_definition: LabItemDefinition
@export_range(1, 999) var amount: int = 1
@export_range(0.5, 6.0) var reach: float = 2.0
var collected: bool = false

func _ready() -> void:
	monitoring = false
	monitorable = false
	var shape := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 0.45
	shape.shape = sphere
	add_child(shape)
	var mesh := MeshInstance3D.new()
	mesh.name = "IndependentPlaceholder"
	var sphere_mesh := SphereMesh.new()
	sphere_mesh.radius = 0.28
	sphere_mesh.height = 0.56
	mesh.mesh = sphere_mesh
	var finish := StandardMaterial3D.new()
	finish.albedo_color = Color("e5cf79")
	finish.metallic = 0.55
	finish.roughness = 0.35
	mesh.material_override = finish
	add_child(mesh)

func in_reach(player: Node3D) -> bool:
	return not collected and player.global_position.distance_to(global_position) <= reach

func try_collect(player: Node3D, inventory: LabInventory) -> bool:
	if pickup_id.is_empty() or item_definition == null or not in_reach(player):
		return false
	if not inventory.add_item(item_definition.item_id, amount):
		return false
	set_collected(true)
	return true

func set_collected(value: bool) -> void:
	collected = value
	visible = not value
