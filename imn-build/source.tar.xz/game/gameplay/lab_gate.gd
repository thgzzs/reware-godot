class_name LabGate
extends Node3D
## Consumable-key gate demonstration. No inferred N64 puzzle rules.

@export var required_item: StringName = &""
@export_range(1, 999) var item_cost: int = 1
@export_range(0.5, 6.0) var reach: float = 2.6
var is_open: bool = false
var collider: CollisionShape3D
var gate_visual: MeshInstance3D

func _ready() -> void:
	var body := StaticBody3D.new()
	body.name = "GateJoltCollider"
	add_child(body)
	collider = CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.0, 2.3, 0.35)
	collider.position.y = 1.15
	collider.shape = shape
	body.add_child(collider)
	gate_visual = MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = shape.size
	gate_visual.position = collider.position
	gate_visual.mesh = mesh
	var finish := StandardMaterial3D.new()
	finish.albedo_color = Color("587978")
	gate_visual.material_override = finish
	add_child(gate_visual)
	set_open(is_open)

func in_reach(player: Node3D) -> bool:
	return player.global_position.distance_to(global_position) <= reach

func try_unlock(player: Node3D, inventory: LabInventory) -> bool:
	if is_open or not in_reach(player) or not inventory.remove_item(required_item, item_cost):
		return false
	set_open(true)
	return true

func set_open(value: bool) -> void:
	is_open = value
	if collider != null:
		collider.set_deferred("disabled", value)
	if gate_visual != null:
		gate_visual.visible = not value
