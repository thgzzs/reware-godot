class_name LabPlatformMotion
extends RefCounted
## Fallback point velocity uses only a Jolt-confirmed supporting body transform.
## Godot's automatic leave velocity is disabled so inheritance is applied once.
var previous_body: Node3D
var previous_transform := Transform3D.IDENTITY
var local_point := Vector3.ZERO
var velocity := Vector3.ZERO
func reset() -> void:
	previous_body = null
	velocity = Vector3.ZERO
func update(body: CharacterBody3D, delta: float) -> void:
	velocity = Vector3.ZERO
	if not body.is_on_floor():
		previous_body = null
		return
	var support: Node3D
	var contact_point := body.global_position
	for index in body.get_slide_collision_count():
		var collision := body.get_slide_collision(index)
		if collision.get_normal().dot(Vector3.UP) >= cos(body.floor_max_angle):
			support = collision.get_collider() as Node3D
			contact_point = collision.get_position()
			break
	if support == null:
		previous_body = null
		return
	velocity = body.get_platform_velocity()
	if support == previous_body and is_instance_valid(previous_body) and velocity.length_squared() < 0.000001:
		velocity = (support.global_transform * local_point - previous_transform * local_point) / delta
	previous_body = support
	previous_transform = support.global_transform
	local_point = support.to_local(contact_point)
