class_name LabRigidBodyInteraction
extends RefCounted
static func push_contacts(body: CharacterBody3D, intended_velocity: Vector3, delta: float, profile: LabMovementProfile) -> void:
	for index in body.get_slide_collision_count():
		var contact := body.get_slide_collision(index)
		var rigid := contact.get_collider() as RigidBody3D
		if rigid == null or rigid.freeze or absf(contact.get_normal().y) > 0.25:
			continue
		var direction := -contact.get_normal()
		direction.y = 0.0
		var relative_speed := maxf((intended_velocity - rigid.linear_velocity).dot(direction), 0.0)
		var impulse := minf(profile.push_force * delta, relative_speed * profile.push_effective_mass)
		if impulse > 0.0:
			rigid.apply_impulse(direction.normalized() * impulse, contact.get_position() - rigid.global_position)
