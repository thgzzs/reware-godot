class_name LabPhysicsQueries
extends RefCounted
## Geometry comes exclusively from the active built-in Jolt physics space.
static func ray(body: CharacterBody3D, origin: Vector3, destination: Vector3) -> Dictionary:
	var query := PhysicsRayQueryParameters3D.create(origin, destination, body.collision_mask, [body.get_rid()])
	query.collide_with_areas = false
	return body.get_world_3d().direct_space_state.intersect_ray(query)
static func capsule_clear(body: CharacterBody3D, foot: Vector3, height: float, radius: float) -> bool:
	var capsule := CapsuleShape3D.new()
	capsule.radius = radius
	capsule.height = height
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = capsule
	query.transform = Transform3D(Basis.IDENTITY, foot + Vector3.UP * (height * 0.5 + 0.015))
	query.collision_mask = body.collision_mask
	query.exclude = [body.get_rid()]
	query.collide_with_areas = false
	query.margin = 0.0
	return body.get_world_3d().direct_space_state.intersect_shape(query, 1).is_empty()
static func supported(body: CharacterBody3D, foot: Vector3, drop: float = 0.18) -> bool:
	var result := ray(body, foot + Vector3.UP * 0.08, foot - Vector3.UP * drop)
	return not result.is_empty() and Vector3(result.normal).dot(Vector3.UP) >= cos(body.floor_max_angle)
