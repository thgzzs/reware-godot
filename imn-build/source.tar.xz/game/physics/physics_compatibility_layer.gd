class_name LabPhysicsCompatibilityLayer
extends RefCounted
## Original provisional movement rules atop Jolt, never an N64 physics runtime.
var water_zones: Array[LabWaterZone] = []
var climb_zones: Array[LabClimbZone] = []
var climbing: LabClimbZone
var ledge: Dictionary = {}
var mantling: bool = false
var mantle_elapsed: float = 0.0
var mantle_origin := Vector3.ZERO
var crouched: bool = false
var traversal_lockout: float = 0.0

func reset() -> void:
	climbing = null
	ledge.clear()
	mantling = false
	mantle_elapsed = 0.0
	crouched = false
	traversal_lockout = 0.0
	water_zones.clear()
	climb_zones.clear()

func refresh_zones(body: CharacterBody3D) -> void:
	water_zones.clear()
	climb_zones.clear()
	var query := PhysicsPointQueryParameters3D.new()
	query.position = body.global_position + Vector3.UP * 0.4
	query.collision_mask = 4
	query.collide_with_areas = true
	query.collide_with_bodies = false
	for result in body.get_world_3d().direct_space_state.intersect_point(query, 32):
		var zone: Object = result.collider
		if zone is LabWaterZone: water_zones.append(zone)
		if zone is LabClimbZone: climb_zones.append(zone)

func water(body: CharacterBody3D, profile: LabMovementProfile) -> LabWaterZone:
	for zone in water_zones:
		if is_instance_valid(zone) and body.global_position.y < zone.surface_y - profile.swim_surface_offset + 0.12:
			return zone
	return null

func update_crouch(body: CharacterBody3D, collision: CollisionShape3D, requested: bool, profile: LabMovementProfile) -> void:
	if requested:
		crouched = true
	elif crouched and LabPhysicsQueries.capsule_clear(body, body.global_position, profile.standing_height, profile.capsule_radius):
		crouched = false
	var height := profile.crouching_height if crouched else profile.standing_height
	(collision.shape as CapsuleShape3D).height = height
	collision.position.y = height * 0.5

func special_tick(body: CharacterBody3D, intent: LabMovementIntent, direction: Vector3, forward: Vector3, delta: float, profile: LabMovementProfile) -> StringName:
	refresh_zones(body)
	traversal_lockout = maxf(traversal_lockout - delta, 0.0)
	# Active traversal has priority over water so a climb-out is not cancelled mid-motion.
	if mantling:
		mantle_elapsed += delta
		var fraction := minf(mantle_elapsed / profile.mantle_seconds, 1.0)
		var landing: Vector3 = ledge.landing
		if not LabPhysicsQueries.capsule_clear(body, landing, profile.standing_height, profile.capsule_radius) or not LabPhysicsQueries.supported(body, landing):
			mantling = false
			ledge.clear()
			return &"fall"
		var apex := Vector3(mantle_origin.x, landing.y, mantle_origin.z)
		var destination := mantle_origin.lerp(apex, fraction / 0.6) if fraction < 0.6 else apex.lerp(landing, (fraction - 0.6) / 0.4)
		body.velocity = Vector3.ZERO
		if body.move_and_collide(destination - body.global_position) != null:
			mantling = false
			ledge.clear()
			traversal_lockout = 0.25
			return &"fall"
		if fraction >= 1.0:
			mantling = false
			ledge.clear()
			body.apply_floor_snap()
			return &"landing"
		return &"mantling"
	if not ledge.is_empty():
		body.velocity = Vector3.ZERO
		if not LabPhysicsQueries.supported(body, ledge.landing):
			ledge.clear()
			return &"fall"
		if intent.crouch:
			ledge.clear()
			traversal_lockout = 0.35
			return &"fall"
		if intent.jump or intent.traverse:
			if LabPhysicsQueries.capsule_clear(body, ledge.landing, profile.standing_height, profile.capsule_radius):
				mantling = true
				mantle_elapsed = 0.0
				mantle_origin = body.global_position
				return &"mantling"
		var axis := intent.movement.x
		if absf(axis) > 0.01:
			var shift := Vector3.UP.cross(Vector3(ledge.normal)) * axis * profile.ledge_shimmy_speed * delta
			var candidate := LabStepAndLedgeResolver.can_shimmy(body, ledge, shift, profile)
			if not candidate.is_empty():
				ledge = candidate
				body.global_position = ledge.hang
				return &"ledge_shimmy"
		return &"ledge_hang"
	if climbing != null:
		if not is_instance_valid(climbing):
			climbing = null
			return &"fall"
		if intent.jump or intent.crouch:
			body.velocity = climbing.wall_normal.normalized() * 2.0 + Vector3.UP * (2.0 if intent.jump else 0.0)
			climbing = null
			traversal_lockout = 0.35
			return &"fall"
		LabClimbingResolver.tick(body, climbing, -intent.movement.y, delta, profile)
		if body.global_position.y >= climbing.top_y - 0.02 and intent.movement.y < -0.01:
			var exit := body.global_position - climbing.wall_normal.normalized() * profile.climb_exit_distance + Vector3.UP * 0.02
			if LabPhysicsQueries.capsule_clear(body, exit, profile.standing_height, profile.capsule_radius) and LabPhysicsQueries.supported(body, exit) and not body.test_move(body.global_transform, exit - body.global_position):
				body.global_position = exit
				climbing = null
				return &"landing"
		if body.global_position.y <= climbing.bottom_y + 0.02 and intent.movement.y > 0.01:
			climbing = null
			return &"standing"
		return &"climbing"
	var active_water := water(body, profile)
	if active_water != null:
		if intent.traverse and traversal_lockout <= 0.0:
			var candidate := LabStepAndLedgeResolver.find_ledge(body, forward, profile, true)
			if not candidate.is_empty():
				ledge = candidate
				body.global_position = candidate.hang
				body.velocity = Vector3.ZERO
				return &"ledge_hang"
		LabSwimmingResolver.tick(body, active_water, intent, direction, delta, profile)
		return &"swimming"
	if intent.traverse and traversal_lockout <= 0.0 and not crouched:
		for zone in climb_zones:
			if is_instance_valid(zone) and LabClimbingResolver.attach(body, zone, profile):
				climbing = zone
				return &"climbing"
		var candidate := LabStepAndLedgeResolver.find_ledge(body, forward, profile)
		if not candidate.is_empty():
			ledge = candidate
			body.global_position = candidate.hang
			body.velocity = Vector3.ZERO
			return &"ledge_hang"
	return &""
