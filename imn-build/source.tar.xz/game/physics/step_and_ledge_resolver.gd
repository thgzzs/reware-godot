class_name LabStepAndLedgeResolver
extends RefCounted
## Independently authored traversal rules using only the active Jolt space.
static func try_step(body: CharacterBody3D, direction: Vector3, delta: float, profile: LabMovementProfile) -> bool:
	if not body.is_on_floor() or direction.length_squared() < 0.001 or body.velocity.y > 0.1:
		return false
	var distance := maxf(Vector2(body.velocity.x, body.velocity.z).length() * delta, 0.12)
	var motion := direction.normalized() * distance
	if not body.test_move(body.global_transform, motion):
		return false
	if body.test_move(body.global_transform, Vector3.UP * profile.step_height):
		return false
	var raised := body.global_transform.translated(Vector3.UP * profile.step_height)
	if body.test_move(raised, motion):
		return false
	var down := KinematicCollision3D.new()
	var across := raised.translated(motion)
	if not body.test_move(across, Vector3.DOWN * (profile.step_height + profile.floor_snap), down):
		return false
	if down.get_normal().dot(Vector3.UP) < cos(body.floor_max_angle):
		return false
	var landing := across.origin + down.get_travel()
	var rise := landing.y - body.global_position.y
	if rise < 0.025 or rise > profile.step_height + 0.01:
		return false
	if not LabPhysicsQueries.capsule_clear(body, landing, profile.standing_height, profile.capsule_radius):
		return false
	body.global_position = landing + Vector3.UP * 0.01
	body.velocity.y = 0.0
	return true

static func find_ledge(body: CharacterBody3D, forward: Vector3, profile: LabMovementProfile, water: bool = false) -> Dictionary:
	forward.y = 0
	if forward.length_squared() < 0.1:
		return {}
	forward = forward.normalized()
	var reach_height := profile.water_ledge_reach_height if water else profile.ledge_reach_height
	var chest := body.global_position + Vector3.UP * reach_height
	var wall := LabPhysicsQueries.ray(body, chest, chest + forward * profile.ledge_reach)
	if wall.is_empty() or absf(Vector3(wall.normal).y) > 0.15:
		return {}
	var normal := Vector3(wall.normal).normalized()
	if normal.dot(-forward) < 0.65:
		return {}
	var behind_wall := Vector3(wall.position) - normal * (profile.capsule_radius + 0.12)
	var top := LabPhysicsQueries.ray(body, behind_wall + Vector3.UP * profile.ledge_probe_height, behind_wall - Vector3.UP * 0.05)
	if top.is_empty() or Vector3(top.normal).dot(Vector3.UP) < cos(body.floor_max_angle):
		return {}
	var landing := Vector3(top.position)
	var height := landing.y - body.global_position.y
	if height < reach_height or height > reach_height + profile.ledge_probe_height:
		return {}
	if not LabPhysicsQueries.capsule_clear(body, landing, profile.standing_height, profile.capsule_radius):
		return {}
	var hang := Vector3(wall.position) + normal * (profile.capsule_radius + 0.04)
	hang.y = landing.y - profile.ledge_hang_offset
	if not LabPhysicsQueries.capsule_clear(body, hang, profile.standing_height, profile.capsule_radius):
		return {}
	return {"hang": hang, "landing": landing + Vector3.UP * 0.015, "normal": normal}

static func can_shimmy(body: CharacterBody3D, ledge: Dictionary, shift: Vector3, profile: LabMovementProfile) -> Dictionary:
	var foot := body.global_position
	var shifted := foot + shift
	if not LabPhysicsQueries.capsule_clear(body, shifted, profile.standing_height, profile.capsule_radius):
		return {}
	body.global_position = shifted
	var next := find_ledge(body, -Vector3(ledge.normal), profile)
	body.global_position = foot
	if next.is_empty() or absf(Vector3(next.landing).y - Vector3(ledge.landing).y) > 0.15:
		return {}
	return next
