class_name LabWaterZone
extends Area3D
## Authored laboratory water, not a decoded original water resource.
@export var surface_y: float = 0.0
func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	body_entered.connect(func(body: Node3D) -> void:
		if body.has_method("enter_water_zone"): body.enter_water_zone(self))
	body_exited.connect(func(body: Node3D) -> void:
		if body.has_method("exit_water_zone"): body.exit_water_zone(self))
