class_name LabSwimmingResolver
extends RefCounted
static func tick(body: CharacterBody3D, zone: LabWaterZone, intent: LabMovementIntent, direction: Vector3, delta: float, profile: LabMovementProfile) -> void:
	var target := direction * profile.swim_speed
	target.y = (float(intent.jump_held) - float(intent.crouch)) * profile.swim_vertical_speed
	body.velocity = body.velocity.move_toward(target, profile.swim_acceleration * delta)
	if body.global_position.y >= zone.surface_y - profile.swim_surface_offset and body.velocity.y > 0:
		body.velocity.y = 0.0
	body.move_and_slide()
	if body.global_position.y > zone.surface_y - profile.swim_surface_offset:
		body.global_position.y = zone.surface_y - profile.swim_surface_offset
