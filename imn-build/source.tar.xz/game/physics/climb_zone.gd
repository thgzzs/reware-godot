class_name LabClimbZone
extends Area3D
## Authored ladder; all coordinates below are in world space.
@export var bottom_y: float = 0.0
@export var top_y: float = 3.0
@export var climb_anchor := Vector3.ZERO
@export var wall_normal := Vector3.BACK
func _ready() -> void:
	collision_layer = 4
	collision_mask = 1
	body_entered.connect(func(body: Node3D) -> void:
		if body.has_method("enter_climb_zone"): body.enter_climb_zone(self))
	body_exited.connect(func(body: Node3D) -> void:
		if body.has_method("exit_climb_zone"): body.exit_climb_zone(self))
