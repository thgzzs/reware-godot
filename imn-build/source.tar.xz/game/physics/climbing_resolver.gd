class_name LabClimbingResolver
extends RefCounted
static func attach(body: CharacterBody3D, zone: LabClimbZone, profile: LabMovementProfile) -> bool:
	if not is_instance_valid(zone) or zone.top_y <= zone.bottom_y:
		return false
	var destination := Vector3(zone.climb_anchor.x, clampf(body.global_position.y, zone.bottom_y, zone.top_y), zone.climb_anchor.z)
	if body.global_position.distance_to(destination) > profile.climb_attach_distance:
		return false
	if not LabPhysicsQueries.capsule_clear(body, destination, profile.standing_height, profile.capsule_radius):
		return false
	body.global_position = destination
	body.velocity = Vector3.ZERO
	return true
static func tick(body: CharacterBody3D, zone: LabClimbZone, axis: float, delta: float, profile: LabMovementProfile) -> bool:
	var destination := body.global_position
	destination.y = clampf(destination.y + axis * profile.climb_speed * delta, zone.bottom_y, zone.top_y)
	body.velocity = Vector3.ZERO
	return body.move_and_collide(destination - body.global_position) == null
