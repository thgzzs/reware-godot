class_name LabGroundContactResolver
extends RefCounted
static func state(body: CharacterBody3D, moving: bool, running: bool, landing: bool) -> StringName:
	if not body.is_on_floor():
		return &"jump" if body.velocity.y > 0.0 else &"fall"
	if landing:
		return &"landing"
	if not moving:
		return &"standing"
	return &"running" if running else &"walking"
