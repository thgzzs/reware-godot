class_name LabSlopeBehavior
extends RefCounted
static func steep_normal(body: CharacterBody3D, profile: LabMovementProfile) -> Vector3:
	for index in body.get_slide_collision_count():
		var normal := body.get_slide_collision(index).get_normal()
		if normal.y > 0.05 and normal.y < cos(deg_to_rad(profile.maximum_slope_degrees)):
			return normal
	return Vector3.ZERO
static func apply_slide(body: CharacterBody3D, normal: Vector3, delta: float, profile: LabMovementProfile) -> void:
	body.velocity += Vector3.DOWN.slide(normal).normalized() * profile.slide_acceleration * delta
