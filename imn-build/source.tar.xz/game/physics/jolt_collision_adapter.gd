class_name LabJoltCollisionAdapter
extends RefCounted
## Jolt remains the collision foundation; no N64 physics runtime is present.
static func configure(body: CharacterBody3D, profile: LabMovementProfile) -> void:
	body.floor_snap_length = profile.floor_snap
	body.floor_max_angle = deg_to_rad(profile.maximum_slope_degrees)
	body.safe_margin = 0.01
	body.floor_stop_on_slope = true
	body.floor_constant_speed = true

static func step(body: CharacterBody3D) -> bool:
	return body.move_and_slide()
