class_name LabMovementIntent
extends RefCounted
var movement := Vector2.ZERO
var run: bool = false
var jump: bool = false
var jump_held: bool = false
var crouch: bool = false
var traverse: bool = false
static func from_actions() -> LabMovementIntent:
	var intent := LabMovementIntent.new()
	intent.movement = Input.get_vector(&"move_left", &"move_right", &"move_forward", &"move_back")
	intent.run = Input.is_action_pressed(&"run")
	intent.jump = Input.is_action_just_pressed(&"jump")
	intent.jump_held = Input.is_action_pressed(&"jump")
	intent.crouch = Input.is_action_pressed(&"crouch") if InputMap.has_action(&"crouch") else false
	intent.traverse = Input.is_action_just_pressed(&"traverse") if InputMap.has_action(&"traverse") else false
	return intent
