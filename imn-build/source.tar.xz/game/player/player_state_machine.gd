class_name LabPlayerStateMachine
extends RefCounted
## Original provisional movement modes. No original game-state values are asserted.
const STATES: Array[StringName] = [&"standing", &"walking", &"running", &"jump", &"fall", &"landing", &"crouching", &"crouch_walk", &"sliding", &"climbing", &"ledge_hang", &"ledge_shimmy", &"mantling", &"swimming"]
var current: StringName = &"fall"
var previous: StringName = &"fall"
var ticks_in_state: int = 0
func transition(next: StringName) -> bool:
	assert(STATES.has(next), "Unknown movement mode")
	if next == current:
		ticks_in_state += 1
		return false
	previous = current
	current = next
	ticks_in_state = 0
	return true
func reset(next: StringName = &"fall") -> void:
	assert(STATES.has(next))
	current = next
	previous = next
	ticks_in_state = 0
