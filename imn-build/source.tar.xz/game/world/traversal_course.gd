class_name LabTraversalCourse
extends RefCounted
## Independently authored fixtures. These are not reconstructed original levels.
static func sign_at(world: Node3D, caption: String, location: Vector3) -> void:
	var label := Label3D.new()
	label.text = caption
	label.position = location
	label.font_size = 36
	label.pixel_size = 0.005
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.outline_size = 10
	world.add_child(label)

static func area_shape(area: Area3D, dimensions: Vector3) -> void:
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = dimensions
	collision.shape = shape
	area.add_child(collision)

static func build(world: LabWorld) -> void:
	var stone := Color("68746e")
	world.block("PoolBottom", Vector3(0, -3.4, -10), Vector3(6, 0.8, 6), stone)
	world.block("PoolWest", Vector3(-3.3, -1.8, -10), Vector3(0.6, 3.6, 6.6), stone)
	world.block("PoolEast", Vector3(3.3, -1.8, -10), Vector3(0.6, 3.6, 6.6), stone)
	world.block("PoolNorth", Vector3(0, -1.8, -13.3), Vector3(6, 3.6, 0.6), stone)
	world.block("PoolSouth", Vector3(0, -1.8, -6.7), Vector3(6, 3.6, 0.6), stone)
	var water := LabWaterZone.new()
	water.name = "TrainingWater"
	water.position = Vector3(0, -1.5, -10)
	water.surface_y = 0.0
	area_shape(water, Vector3(6, 3, 6))
	world.add_child(water)
	var surface := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(6, 6)
	surface.mesh = plane
	surface.position = Vector3(0, -0.02, -10)
	var material := world.material(Color(0.12, 0.48, 0.6, 0.48))
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	surface.material_override = material
	world.add_child(surface)
	sign_at(world, "SWIM\nSpace: rise  C: dive  F: edge exit", Vector3(0, 2.1, -10))
	world.block("ClimbWall", Vector3(-14, 1.75, -7.8), Vector3(3.2, 3.5, 0.8), stone)
	world.block("ClimbLanding", Vector3(-14, 3.3, -9.3), Vector3(3.2, 0.4, 3), stone)
	var climb := LabClimbZone.new()
	climb.name = "TrainingLadder"
	climb.position = Vector3(-14, 1.75, -6.9)
	climb.bottom_y = 0.0
	climb.top_y = 3.5
	climb.wall_normal = Vector3.BACK
	climb.climb_anchor = Vector3(-14, 0, -6.9)
	area_shape(climb, Vector3(2.4, 4.5, 1))
	world.add_child(climb)
	for index in 10:
		world.block("LadderRung", Vector3(-14, 0.25 + index * 0.33, -7.32), Vector3(1.5, 0.08, 0.08), Color("b29a69"))
	sign_at(world, "LADDER\nF: attach  W/S: climb  Space: detach", Vector3(-14, 4.6, -7.7))
	world.block("HangLedge", Vector3(12, 0.9, -4.5), Vector3(4, 1.8, 3), Color("ad987a"))
	sign_at(world, "LEDGE\nF: grab  A/D: shimmy\nSpace: mantle  C: drop", Vector3(12, 3, -4.5))
	world.block("CrawlRoof", Vector3(0, 1.25, 2), Vector3(3, 0.3, 3), stone)
	world.block("CrawlSupportL", Vector3(-1.65, 0.6, 2), Vector3(0.3, 1.2, 3), stone)
	world.block("CrawlSupportR", Vector3(1.65, 0.6, 2), Vector3(0.3, 1.2, 3), stone)
	sign_at(world, "LOW PASSAGE\nHold C: crouch", Vector3(0, 2.4, 2))
	var platform := LabMovingPlatform.new()
	platform.name = "TrainingMovingPlatform"
	platform.position = Vector3(-6, 0.5, 10)
	world.add_child(platform)
	sign_at(world, "MOVING PLATFORM\nJump aboard", Vector3(-6, 2.8, 10))
	var crate := RigidBody3D.new()
	crate.name = "PushableCrate"
	crate.position = Vector3(8, 0.55, 0)
	crate.mass = 4
	crate.lock_rotation = true
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3.ONE
	collision.shape = shape
	crate.add_child(collision)
	var visual := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3.ONE
	visual.mesh = mesh
	visual.material_override = world.material(Color("92633d"))
	crate.add_child(visual)
	world.add_child(crate)
	sign_at(world, "PUSHABLE\nWalk against crate", Vector3(8, 2.5, 0))
