class_name LabMovingPlatform
extends AnimatableBody3D
@export var travel := Vector3(2.5, 0, 0)
@export var period: float = 6.0
var origin: Vector3
var ticks: int = 0

func _ready() -> void:
	origin = position
	sync_to_physics = false
	process_physics_priority = -20
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(3, 0.4, 3)
	collision.shape = shape
	add_child(collision)
	var visual := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = shape.size
	visual.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("a67958")
	visual.material_override = material
	add_child(visual)

func _physics_process(_delta: float) -> void:
	ticks += 1
	position = origin + travel * sin(TAU * float(ticks) / (float(Engine.physics_ticks_per_second) * maxf(period, 0.1)))
