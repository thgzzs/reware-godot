extends SceneTree

var failures: Array[String] = []
var checks: Array[String] = []
var lab: LabWorld

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	checks.append(description)
	if not condition:
		failures.append(description)
		push_error("FAILED: " + description)

func frames(count: int) -> void:
	for _index in count:
		await physics_frame
	await process_frame

func run() -> void:
	var version := Engine.get_version_info()
	check(version.major >= 4 and (version.minor > 7 or (version.minor == 7 and version.patch >= 2)), "Godot minimum 4.7.2")
	check(ProjectSettings.get_setting("physics/3d/physics_engine") == "Jolt Physics", "Built-in Jolt configured")
	check(ClassDB.class_exists("JoltPhysicsServer3D"), "Built-in Jolt server module is present")
	check(ProjectSettings.get_setting("rendering/renderer/rendering_method") == "forward_plus", "Forward+ configured")
	check(ProjectSettings.get_setting("rendering/renderer/rendering_method.mobile") == "forward_plus", "Forward+ Android configured")
	check(ProjectSettings.get_setting("physics/common/physics_ticks_per_second") == 60, "Fixed 60Hz simulation")
	lab = LabWorld.new()
	lab.save_path = "user://smoke_checkpoint.json"
	root.add_child(lab)
	lab.player.input_enabled = false
	lab.player.teleport(Vector3(0, 0.2, 12))
	await frames(60)
	check(lab.player.is_on_floor() and absf(lab.player.position.y) < 0.04, "Jolt capsule settles onto courtyard")
	lab.player.test_input = Vector2.RIGHT
	var start := lab.player.position
	await frames(120)
	check(absf(lab.player.velocity.x - lab.player.profile.walk_speed) < 0.02, "Walking reaches provisional profile speed")
	check(lab.player.position.x - start.x > 5.4 and lab.player.position.x - start.x < 6.2, "Fixed-tick walking advances expected test distance")
	check(lab.player.movement_state == &"walking", "Walking state transition")
	lab.player.test_running = true
	await frames(45)
	check(absf(lab.player.velocity.x - lab.player.profile.run_speed) < 0.02, "Running reaches provisional profile speed")
	check(lab.player.movement_state == &"running", "Running state transition")
	lab.player.test_input = Vector2.ZERO
	await frames(25)
	check(Vector2(lab.player.velocity.x, lab.player.velocity.z).length() < 0.001, "Ground deceleration stops movement")
	var jump_start := lab.player.position.y
	lab.player.test_jump = true
	var peak := jump_start
	var states: Dictionary = {}
	for _index in 80:
		await physics_frame
		peak = maxf(peak, lab.player.position.y)
		states[lab.player.movement_state] = true
	await process_frame
	check(peak - jump_start > 0.8 and peak - jump_start < 1.2, "Jolt jump has provisional expected apex")
	check(states.has(&"jump") and states.has(&"fall") and states.has(&"landing") and states.has(&"standing"), "Jump fall landing standing transitions")
	check(lab.player.is_on_floor(), "Jump returns to Jolt ground contact")
	lab.player.teleport(Vector3(-5, 0.2, -6))
	await frames(10)
	check(FileAccess.file_exists(lab.save_path), "Area3D checkpoint writes save")
	check(lab.checkpoint.distance_to(Vector3(-5, 0.2, -6)) < 0.001, "Checkpoint trigger updates destination")
	lab.player.teleport(Vector3(5, 0.2, -7))
	check(lab.interact() and lab.beacon_active, "Nearby interaction toggles beacon")
	lab.player.teleport(Vector3(0, 0.2, 7))
	check(not lab.interact(), "Interaction rejects distant player")
	check(lab.restore_checkpoint(), "Valid checkpoint restores")
	check(lab.player.position.distance_to(lab.checkpoint) < 0.001 and lab.beacon_active, "Restore preserves checkpoint position and beacon outcome")
	check(not LabSaveStore.validate({"schema": 1, "position": [NAN, 0, 0], "yaw": 0, "beacon": false}), "Save rejects non-finite position")
	check(not LabSaveStore.validate({"schema": 2, "position": [0, 0, 0], "yaw": 0, "beacon": false}), "Save rejects unknown schema")
	check(not LabSaveStore.validate({"schema": 1, "position": [0, 0, 0], "yaw": 0, "beacon": "false"}), "Save rejects wrong boolean type")
	var invalid := FileAccess.open(lab.save_path, FileAccess.WRITE)
	invalid.store_string("{truncated")
	invalid.close()
	var before := lab.player.position
	check(not lab.restore_checkpoint() and lab.player.position == before, "Corrupt save is rejected without changing player position")
	lab.touch.enabled = true
	var press := InputEventScreenTouch.new()
	press.index = 1
	press.position = lab.touch.button_center(0)
	press.pressed = true
	lab.touch._input(press)
	check(Input.is_action_pressed(&"jump"), "Touch jump presses shared action")
	var movement := InputEventScreenTouch.new()
	movement.index = 2
	movement.position = Vector2(100, 500)
	movement.pressed = true
	lab.touch._input(movement)
	var drag := InputEventScreenDrag.new()
	drag.index = 2
	drag.position = Vector2(100, 430)
	lab.touch._input(drag)
	check(Input.get_action_strength(&"move_forward") > 0.9, "Touch joystick produces shared movement strength")
	lab.touch._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
	check(not Input.is_action_pressed(&"jump") and not Input.is_action_pressed(&"move_forward") and lab.touch.held.is_empty(), "Application focus loss releases all virtual actions")
	lab.touch._input(press)
	lab.touch._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
	check(not Input.is_action_pressed(&"jump") and lab.touch.fingers.is_empty(), "Android pause clears held fingers and actions")
	lab.touch._input(press)
	lab.touch._notification(Node.NOTIFICATION_WM_WINDOW_FOCUS_OUT)
	check(not Input.is_action_pressed(&"jump"), "Window focus loss releases virtual actions")
	lab.original_framing = true
	lab.update_framing()
	check(lab.left_bar.size.x >= 0.0 and lab.right_bar.size.x == lab.left_bar.size.x, "4:3 presentation crop is symmetric")
	lab.touch._input(press)
	lab.touch.queue_free()
	await process_frame
	check(not Input.is_action_pressed(&"jump"), "Removing controls releases virtual action")
	var report := {"schema": 1, "kind": "native_prototype_integration", "engine": version.string, "checks": checks, "check_count": checks.size(), "failures": failures, "passed": failures.is_empty(), "reference_comparison": "NOT_PERFORMED", "headless": true}
	var report_file := FileAccess.open("res://reports/native_integration_v0.4.json", FileAccess.WRITE)
	if report_file:
		report_file.store_string(JSON.stringify(report, "\t"))
	print(JSON.stringify(report))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
