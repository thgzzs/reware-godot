extends SceneTree
## Requires Godot 4.7.2 with Jolt. Checks synthetic, not ROM-calibrated, gameplay.
var errors: Array[String] = []
var checks: Array[String] = []
var world: LabWorld

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, explanation: String) -> void:
	checks.append(explanation)
	if not ok:
		errors.append(explanation)
		push_error("GAMEPLAY_FAIL " + explanation)

func ticks(count: int) -> void:
	for _tick in count:
		await physics_frame
	await process_frame

func run() -> void:
	world = LabWorld.new()
	world.save_path = "user://gameplay_v05_smoke.json"
	root.add_child(world)
	world.player.input_enabled = false
	await ticks(3)
	check(world.inventory.quantity(&"brass_key") == 0, "Starts with empty inventory")
	check(not world.inventory.add_item(&"unknown", 1), "Rejects unregistered items")
	check(not world.inventory.add_item(&"brass_key", -1), "Rejects negative item increments")
	world.player.teleport(Vector3(13, 0.2, 9))
	check(not world.interact() and not world.gate.is_open, "Locked gate refuses missing key")
	world.player.teleport(Vector3(2, 0.2, 12))
	check(world.interact(), "Collectible can be acquired near player")
	check(world.pickup.collected and world.inventory.quantity(&"brass_key") == 1, "Pickup is idempotent and adds one item")
	check(not world.inventory.add_item(&"brass_key"), "Stack capacity is enforced")
	var json_roundtrip: Dictionary = JSON.parse_string(JSON.stringify(world.inventory.to_save_data()))
	check(world.inventory.restore_save_data(json_roundtrip) and world.inventory.quantity(&"brass_key") == 1, "JSON float count roundtrip accepts only whole quantities")
	check(not world.inventory.restore_save_data({"brass_key": 0.5}) and world.inventory.quantity(&"brass_key") == 1, "Fractional JSON inventory count is rejected atomically")
	check(not world.inventory.remove_item(&"brass_key", 2), "Removal is all-or-nothing")
	world.player.teleport(Vector3(13, 0.2, 9))
	check(world.interact() and world.gate.is_open, "Gate consumes key and opens")
	check(world.inventory.quantity(&"brass_key") == 0, "Gate consumed exactly one key")
	check(not world.interact(), "Unlocked gate cannot be unlocked again")
	var before := world.progress_snapshot()
	check(world.persist_checkpoint() == OK, "Progress can be persisted")
	world.gate.set_open(false)
	world.pickup.set_collected(false)
	check(world.restore_checkpoint(), "Progress can be restored")
	check(world.progress_snapshot() == before, "Restore preserves gate and pickup outcome")
	var snapshot := world.inventory.to_save_data()
	check(not world.inventory.restore_save_data({"brass_key": 1, "forged_key": 2}), "Unknown save key rejects entire inventory transaction")
	check(world.inventory.to_save_data() == snapshot, "Invalid inventory cannot partially mutate state")
	var invalid := LabSaveStore.encode(Vector3.ZERO, 0.0, false, {"inventory": {"brass_key": -1}, "collected_pickups": [], "gate_open": true})
	check(not LabSaveStore.validate(invalid), "Rejects negative saved inventory")
	invalid["progress"]["inventory"] = {"brass_key": 0}
	invalid["progress"]["collected_pickups"] = ["same", "same"]
	check(not LabSaveStore.validate(invalid), "Rejects duplicate pickup IDs")
	var legacy := LabSaveStore.encode(Vector3(2, 0.2, 7), 0.0, false)
	check(LabSaveStore.validate(legacy), "Legacy v0.4 checkpoint format remains valid")
	world.inventory.add_item(&"brass_key")
	world.restore_progress({"inventory": {}, "collected_pickups": [], "gate_open": false})
	check(world.inventory.quantity(&"brass_key") == 0 and not world.gate.is_open and not world.pickup.collected, "Missing legacy progress resets all synthetic gameplay state")
	var output := {"schema": 1, "release": "0.5.0", "kind": "gameplay_lab", "checks": checks, "checks_run": checks.size(), "failures": errors, "passed": errors.is_empty(), "reference_comparison": "NOT_PERFORMED", "mode": "Godot Jolt native integration"}
	print(JSON.stringify(output))
	var out_file := FileAccess.open("res://reports/gameplay_lab_v0.5.json", FileAccess.WRITE)
	if out_file != null:
		out_file.store_string(JSON.stringify(output, "\t"))
		out_file.close()
	world.queue_free()
	await process_frame
	quit(0 if errors.is_empty() else 1)
