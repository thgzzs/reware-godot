class_name LabPlayer
extends CharacterBody3D

signal state_changed(previous: StringName, current: StringName)
var profile: LabMovementProfile = preload("res://resources/behavior_profiles/provisional.tres")
var movement_state: StringName = &"fall"
var landing_time: float = 0.0
var orbit: LabOrbitCamera
var avatar: LabCharacterAvatar
var capsule_collision: CollisionShape3D
var state_machine := LabPlayerStateMachine.new()
var compatibility := LabPhysicsCompatibilityLayer.new()
var platform_motion := LabPlatformMotion.new()
var actions := LabActionController.new()
var action_test_intent: LabActionIntent = null
var input_enabled: bool = true
var test_input := Vector2.ZERO
var test_running: bool = false
var test_jump: bool = false
var test_jump_held: bool = false
var test_crouch: bool = false
var test_traverse: bool = false

func _ready() -> void:
	LabJoltCollisionAdapter.configure(self, profile)
	platform_on_leave = CharacterBody3D.PLATFORM_ON_LEAVE_DO_NOTHING
	capsule_collision = CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = profile.capsule_radius
	capsule.height = profile.standing_height
	capsule_collision.shape = capsule
	capsule_collision.position.y = profile.standing_height * 0.5
	add_child(capsule_collision)
	avatar = LabCharacterAvatar.new()
	avatar.name = "OriginalReplacementAvatar"
	add_child(avatar)
	orbit = LabOrbitCamera.new()
	orbit.position.y = 1.25
	add_child(orbit)
	orbit.arm.spring_length = profile.camera_distance
	orbit.camera.fov = profile.camera_fov
	orbit.arm.add_excluded_object(get_rid())

func intent_for_tick() -> LabMovementIntent:
	if input_enabled:
		return LabMovementIntent.from_actions()
	var intent := LabMovementIntent.new()
	intent.movement = test_input.limit_length()
	intent.run = test_running
	intent.jump = test_jump
	intent.jump_held = test_jump_held
	intent.crouch = test_crouch
	intent.traverse = test_traverse
	test_jump = false
	test_traverse = false
	return intent

func _action_tick(delta: float, blocked: bool) -> void:
	var wish := LabActionIntent.from_actions() if input_enabled else (action_test_intent if action_test_intent != null else LabActionIntent.new())
	var facing := -orbit.camera.global_transform.basis.z
	facing.y = 0.0
	if facing.is_zero_approx(): facing = -avatar.global_basis.z
	actions.tick(delta, wish, self, facing.normalized(), blocked)
	if actions.last_event in [&"shot", &"whip", &"draw", &"holster"]:
		avatar.play_action(actions.last_event)

func _physics_process(delta: float) -> void:
	var intent := intent_for_tick()
	var direction := Vector3(intent.movement.x, 0, intent.movement.y).rotated(Vector3.UP, orbit.yaw)
	platform_motion.update(self, delta)
	var special := compatibility.special_tick(self, intent, direction, -avatar.global_basis.z, delta, profile)
	if special != &"":
		_action_tick(delta, special not in [&"standing", &"walking", &"running", &"crouching", &"swimming"])
		if special == &"landing": landing_time = profile.landing_seconds
		_set_state(special)
		return
	compatibility.update_crouch(self, capsule_collision, intent.crouch, profile)
	avatar.set_crouched(compatibility.crouched)
	var grounded := is_on_floor()
	_action_tick(delta, false)
	landing_time = maxf(landing_time - delta, 0.0)
	var speed := profile.crouch_speed if compatibility.crouched else (profile.run_speed if intent.run else profile.walk_speed)
	if input_enabled and Input.is_action_pressed(&"aim"): speed *= actions.profile.aim_walk_multiplier
	var acceleration := profile.acceleration if grounded else profile.air_acceleration
	if intent.movement.is_zero_approx(): acceleration = profile.deceleration if grounded else 0.0
	velocity.x = move_toward(velocity.x, direction.x * speed, acceleration * delta)
	velocity.z = move_toward(velocity.z, direction.z * speed, acceleration * delta)
	if grounded and intent.jump and not compatibility.crouched:
		velocity += platform_motion.velocity
		velocity.y = profile.jump_speed + maxf(platform_motion.velocity.y, 0.0)
		landing_time = 0.0
	elif not grounded:
		velocity.y = maxf(velocity.y - profile.gravity * delta, -profile.terminal_speed)
	else:
		velocity.y = 0.0
	if not compatibility.crouched: LabStepAndLedgeResolver.try_step(self, direction, delta, profile)
	var intended := direction * speed
	LabJoltCollisionAdapter.step(self)
	LabRigidBodyInteraction.push_contacts(self, intended, delta, profile)
	var steep := LabSlopeBehavior.steep_normal(self, profile)
	if steep != Vector3.ZERO and not is_on_floor(): LabSlopeBehavior.apply_slide(self, steep, delta, profile)
	if not grounded and is_on_floor(): landing_time = profile.landing_seconds
	if direction.length_squared() > 0.001:
		avatar.rotation.y = lerp_angle(avatar.rotation.y, atan2(-direction.x, -direction.z), minf(12.0 * delta, 1.0))
	var next := LabGroundContactResolver.state(self, intent.movement.length() > 0.01, intent.run, landing_time > 0)
	if is_on_floor() and compatibility.crouched:
		next = &"crouch_walk" if intent.movement.length() > 0.01 else &"crouching"
	elif steep != Vector3.ZERO and not is_on_floor(): next = &"sliding"
	_set_state(next)

func _set_state(next: StringName) -> void:
	state_machine.transition(next)
	avatar.set_state(next)
	if next != movement_state:
		var previous := movement_state
		movement_state = next
		state_changed.emit(previous, next)

func teleport(destination: Vector3, facing_yaw: float = 0.0) -> void:
	global_position = destination
	velocity = Vector3.ZERO
	landing_time = 0.0
	compatibility.reset()
	platform_motion.reset()
	actions.reset()
	if capsule_collision != null:
		(capsule_collision.shape as CapsuleShape3D).height = profile.standing_height
		capsule_collision.position.y = profile.standing_height * 0.5
	avatar.rotation.y = facing_yaw
	avatar.set_crouched(false)
	state_machine.reset()
	movement_state = &"fall"
	reset_physics_interpolation()

func enter_water_zone(zone: LabWaterZone) -> void:
	if not compatibility.water_zones.has(zone): compatibility.water_zones.append(zone)
func exit_water_zone(zone: LabWaterZone) -> void:
	compatibility.water_zones.erase(zone)
func enter_climb_zone(zone: LabClimbZone) -> void:
	if not compatibility.climb_zones.has(zone): compatibility.climb_zones.append(zone)
func exit_climb_zone(zone: LabClimbZone) -> void:
	compatibility.climb_zones.erase(zone)
