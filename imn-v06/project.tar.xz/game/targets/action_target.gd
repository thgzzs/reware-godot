class_name LabActionTarget
extends StaticBody3D
## Synthetic target that proves Jolt ray obstruction, pistol hits and whip activation.
signal hit_received(remaining: int)
signal whip_triggered()
var health: int = 3
var whip_switch: bool = false
var display: MeshInstance3D
func _ready() -> void:
	collision_layer = 1
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(0.85, 1.8, 0.85)
	shape.shape = box
	add_child(shape)
	display = MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = box.size
	display.mesh = mesh
	add_child(display)
	_refresh()
func receive_hit(damage: int) -> void:
	if damage <= 0 or health <= 0:
		return
	health = maxi(0, health - damage)
	hit_received.emit(health)
	_refresh()
func whip_activate() -> void:
	whip_switch = not whip_switch
	whip_triggered.emit()
	_refresh()
func _refresh() -> void:
	if display == null:
		return
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("30d5bb") if whip_switch else (Color("7b3240") if health > 0 else Color("494b51"))
	display.material_override = mat
