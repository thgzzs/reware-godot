class_name LabCharacterAvatar
extends Node3D
## Independently authored eleven-joint replacement. No ROM geometry, textures or clips.
var animation_player: AnimationPlayer
var active_state: StringName = &""
var joints: Dictionary = {}
var action_seconds: float = 0.0
var saved_locomotion: StringName = &"standing"

func _ready() -> void:
	var cloth := _material(Color("8f7757"))
	var trousers := _material(Color("4c565a"))
	var boots := _material(Color("2e3033"))
	var skin := _material(Color("bd9676"))
	_joint("Pelvis", self, Vector3(0, 0.87, 0))
	_box("Hip", joints.Pelvis, Vector3(0.34, 0.19, 0.25), Vector3.ZERO, trousers)
	_joint("Chest", joints.Pelvis, Vector3(0, 0.12, 0))
	_box("Torso", joints.Chest, Vector3(0.43, 0.43, 0.25), Vector3(0, 0.2, 0), cloth)
	_joint("Head", joints.Chest, Vector3(0, 0.54, 0))
	_box("HeadMesh", joints.Head, Vector3(0.25, 0.29, 0.25), Vector3.ZERO, skin)
	_box("Facing", joints.Head, Vector3(0.1, 0.07, 0.07), Vector3(0, 0, -0.14), skin)
	for side in [-1, 1]:
		var prefix := "Left" if side < 0 else "Right"
		_joint(prefix + "Arm", joints.Chest, Vector3(side * 0.28, 0.37, 0))
		_box(prefix + "UpperArmMesh", joints[prefix + "Arm"], Vector3(0.15, 0.29, 0.16), Vector3(0, -0.14, 0), cloth)
		_joint(prefix + "Forearm", joints[prefix + "Arm"], Vector3(0, -0.28, 0))
		_box(prefix + "ForearmMesh", joints[prefix + "Forearm"], Vector3(0.13, 0.28, 0.14), Vector3(0, -0.14, 0), skin)
		_joint(prefix + "Leg", joints.Pelvis, Vector3(side * 0.12, -0.08, 0))
		_box(prefix + "ThighMesh", joints[prefix + "Leg"], Vector3(0.17, 0.37, 0.19), Vector3(0, -0.18, 0), trousers)
		_joint(prefix + "Shin", joints[prefix + "Leg"], Vector3(0, -0.36, 0))
		_box(prefix + "ShinMesh", joints[prefix + "Shin"], Vector3(0.15, 0.34, 0.17), Vector3(0, -0.16, 0), trousers)
		_box(prefix + "BootMesh", joints[prefix + "Shin"], Vector3(0.18, 0.14, 0.28), Vector3(0, -0.34, -0.04), boots)
	animation_player = AnimationPlayer.new()
	animation_player.name = "AnimationPlayer"
	add_child(animation_player)
	var library := AnimationLibrary.new()
	animation_player.add_animation_library("", library)
	for state in LabPlayerStateMachine.STATES:
		library.add_animation(state, _clip(state))
	for action: StringName in [&"shoot", &"whip", &"draw", &"holster"]:
		library.add_animation(action, _clip(action))
	animation_player.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_PHYSICS
	set_state(&"standing")

func _material(color: Color) -> StandardMaterial3D:
	var value := StandardMaterial3D.new()
	value.albedo_color = color
	value.roughness = 0.9
	return value
func _joint(label: String, parent: Node3D, location: Vector3) -> void:
	var node := Node3D.new()
	node.name = label
	node.position = location
	parent.add_child(node)
	joints[label] = node
func _box(label: String, parent: Node3D, dimensions: Vector3, location: Vector3, material: StandardMaterial3D) -> void:
	var visual := MeshInstance3D.new()
	visual.name = label
	var box := BoxMesh.new()
	box.size = dimensions
	visual.mesh = box
	visual.material_override = material
	visual.position = location
	parent.add_child(visual)
func _rotation_track(animation: Animation, joint: String, values: Array[Vector3]) -> void:
	var track := animation.add_track(Animation.TYPE_VALUE)
	animation.track_set_path(track, NodePath(str(get_path_to(joints[joint])) + ":rotation"))
	animation.track_set_interpolation_type(track, Animation.INTERPOLATION_CUBIC)
	for index in values.size():
		animation.track_insert_key(track, animation.length * float(index) / float(values.size() - 1), values[index])
func _clip(state: StringName) -> Animation:
	var animation := Animation.new()
	animation.length = 0.65 if state == &"running" else 1.0
	animation.loop_mode = Animation.LOOP_LINEAR
	var poses: Dictionary = {}
	for joint: String in joints: poses[joint] = [Vector3.ZERO, Vector3.ZERO, Vector3.ZERO]
	if state in [&"walking", &"running", &"crouch_walk", &"climbing", &"ledge_shimmy", &"swimming"]:
		var swing := 0.75 if state == &"running" else 0.45
		poses.LeftLeg = [Vector3(swing, 0, 0), Vector3(-swing, 0, 0), Vector3(swing, 0, 0)]
		poses.RightLeg = [Vector3(-swing, 0, 0), Vector3(swing, 0, 0), Vector3(-swing, 0, 0)]
		poses.LeftArm = [Vector3(-swing, 0, -0.08), Vector3(swing, 0, -0.08), Vector3(-swing, 0, -0.08)]
		poses.RightArm = [Vector3(swing, 0, 0.08), Vector3(-swing, 0, 0.08), Vector3(swing, 0, 0.08)]
	if state in [&"jump", &"fall", &"landing", &"sliding", &"crouching", &"crouch_walk"]:
		for joint: String in ["LeftLeg", "RightLeg"]: poses[joint] = [Vector3(-0.4, 0, 0), Vector3(-0.4, 0, 0), Vector3(-0.4, 0, 0)]
		for joint: String in ["LeftShin", "RightShin"]: poses[joint] = [Vector3(0.8, 0, 0), Vector3(0.8, 0, 0), Vector3(0.8, 0, 0)]
	if state in [&"ledge_hang", &"ledge_shimmy", &"mantling", &"climbing"]:
		poses.LeftArm = [Vector3(PI, 0, -0.12), Vector3(PI, 0, -0.12), Vector3(PI, 0, -0.12)]
		poses.RightArm = [Vector3(PI, 0, 0.12), Vector3(PI, 0, 0.12), Vector3(PI, 0, 0.12)]
	if state == &"shoot":
		poses.RightArm = [Vector3(-1.2, 0, 0), Vector3(-1.4, 0, 0), Vector3(-1.2, 0, 0)]
		poses.RightForearm = [Vector3(-0.25, 0, 0), Vector3(-0.3, 0, 0), Vector3(-0.25, 0, 0)]
	if state == &"whip":
		poses.RightArm = [Vector3(-1.8, 0, -0.4), Vector3(-2.4, 0, 0.3), Vector3(-1.4, 0, 0.1)]
	if state in [&"draw", &"holster"]:
		poses.RightArm = [Vector3(-0.2, 0, 0), Vector3(-0.7, 0, 0), Vector3(-0.2, 0, 0)]
	if state == &"swimming": poses.Chest = [Vector3(-0.55, 0, 0), Vector3(-0.55, 0, 0), Vector3(-0.55, 0, 0)]
	for joint: String in poses:
		var values: Array[Vector3] = []
		for value: Vector3 in poses[joint]: values.append(value)
		_rotation_track(animation, joint, values)
	return animation
func _physics_process(delta: float) -> void:
	if action_seconds > 0.0:
		action_seconds = maxf(action_seconds - delta, 0.0)
		if action_seconds <= 0.0:
			active_state = &""
			set_state(saved_locomotion)

func play_action(kind: StringName) -> void:
	if animation_player == null or kind not in [&"shoot", &"whip", &"draw", &"holster"]:
		return
	action_seconds = 0.23 if kind == &"shoot" else 0.38
	animation_player.play(kind, 0.06)

func set_state(state: StringName) -> void:
	saved_locomotion = state
	if animation_player == null or action_seconds > 0.0 or state == active_state: return
	active_state = state
	animation_player.play(state, 0.12)
func set_crouched(value: bool) -> void:
	scale.y = 0.62 if value else 1.0
