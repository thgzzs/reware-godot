class_name LabWorld
extends Node3D

var player: LabPlayer
var checkpoint := Vector3(0, 0.2, 7)
var beacon_active: bool = false
var inventory := LabInventory.new()
var pickup: LabPickup
var gate: LabGate
var action_target: LabActionTarget
const BRASS_KEY: LabItemDefinition = preload("res://resources/behavior_profiles/lab_brass_key.tres")
var save_path: String = LabSaveStore.SAVE_PATH
var beacon: MeshInstance3D
var beacon_position := Vector3(5, 0.8, -9)
var status: Label
var notice: Label
var original_framing: bool = false
var left_bar: ColorRect
var right_bar: ColorRect
var touch: LabTouchControls
var message: String = "Explore the independently authored test courtyard. Cyan pad saves a checkpoint."

func _ready() -> void:
	LabActions.install()
	var registered := inventory.register_item(BRASS_KEY)
	assert(registered, "Lab item definitions must be unique and valid")
	build_environment()
	build_courtyard()
	player = LabPlayer.new()
	player.name = "Player"
	player.position = checkpoint
	add_child(player)
	build_checkpoint()
	build_gameplay_fixtures()
	build_action_fixture()
	LabTraversalCourse.build(self)
	build_ui()
	touch.look_dragged.connect(player.orbit.look)

func build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("263846")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("a6c3ce")
	environment.ambient_light_energy = 0.55
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_environment.environment = environment
	add_child(world_environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -30, 0)
	sun.light_color = Color("ffe1b8")
	sun.light_energy = 2.3
	sun.shadow_enabled = true
	add_child(sun)

func material(color: Color, emission: bool = false) -> StandardMaterial3D:
	var result := StandardMaterial3D.new()
	result.albedo_color = color
	result.roughness = 0.88
	result.emission_enabled = emission
	result.emission = color
	result.emission_energy_multiplier = 1.0 if emission else 0.0
	return result

func block(label: String, center: Vector3, dimensions: Vector3, color: Color, rotation_z: float = 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = label
	body.position = center
	body.rotation.z = rotation_z
	var visual := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	visual.mesh = mesh
	visual.material_override = material(color)
	body.add_child(visual)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = dimensions
	collision.shape = shape
	body.add_child(collision)
	add_child(body)
	return body

func build_courtyard() -> void:
	block("SouthCourtyard", Vector3(0, -0.5, 6.5), Vector3(36, 1, 27), Color("81725b"))
	block("NorthCourtyard", Vector3(0, -0.5, -16.5), Vector3(36, 1, 7), Color("81725b"))
	block("WestCourtyard", Vector3(-10.5, -0.5, -10), Vector3(15, 1, 6), Color("81725b"))
	block("EastCourtyard", Vector3(10.5, -0.5, -10), Vector3(15, 1, 6), Color("81725b"))
	block("NorthWall", Vector3(0, 1.8, -19), Vector3(36, 3.6, 1), Color("635d51"))
	block("WestWall", Vector3(-17.5, 1.1, 0), Vector3(1, 2.2, 38), Color("635d51"))
	block("EastWall", Vector3(17.5, 1.1, 0), Vector3(1, 2.2, 38), Color("635d51"))
	block("SouthWall", Vector3(0, 1.1, 19), Vector3(36, 2.2, 1), Color("635d51"))
	for x: float in [-10.0, 10.0]:
		for z: float in [-12.0, -3.0, 7.0]:
			block("ColumnBase", Vector3(x, 0.15, z), Vector3(2.1, 0.3, 2.1), Color("afa18a"))
			block("Column", Vector3(x, 2.0, z), Vector3(1.25, 3.4, 1.25), Color("a49378"))
			block("Capital", Vector3(x, 3.8, z), Vector3(1.8, 0.35, 1.8), Color("b5a58b"))
	block("Lintel", Vector3(0, 4.3, -14), Vector3(13, 0.8, 1.8), Color("aea086"))
	for x: float in [-6.0, 6.0]:
		block("GatePillar", Vector3(x, 2, -14), Vector3(1.4, 4.0, 1.4), Color("9e8d73"))
	block("SlopeTest", Vector3(-12.5, 0.65, 13), Vector3(6, 0.6, 4), Color("b4a087"), deg_to_rad(12.0))
	block("LandingTest", Vector3(0, 0.6, -4), Vector3(3, 1.2, 3), Color("9f8b6f"))
	for index in 4:
		block("StepTest", Vector3(4 + index * 0.9, 0.1 * (index + 1), 3), Vector3(0.9, 0.2 * (index + 1), 3), Color("b4a087"))
	beacon = MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.45
	mesh.bottom_radius = 0.7
	mesh.height = 1.6
	beacon.mesh = mesh
	beacon.position = beacon_position
	beacon.material_override = material(Color("e6a840"), true)
	add_child(beacon)

func build_checkpoint() -> void:
	var area := Area3D.new()
	area.name = "Checkpoint"
	area.position = Vector3(-5, 0.3, -6)
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.8, 1.2, 2.8)
	collision.shape = shape
	area.add_child(collision)
	var visual := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 1.4
	mesh.bottom_radius = 1.4
	mesh.height = 0.08
	visual.mesh = mesh
	visual.position.y = -0.24
	visual.material_override = material(Color("35bfc4"), true)
	area.add_child(visual)
	area.body_entered.connect(_checkpoint_entered)
	add_child(area)

func build_gameplay_fixtures() -> void:
	# A synthetic collectible and keyed barrier demonstrate a separated gameplay domain.
	pickup = LabPickup.new()
	pickup.name = "BrassKeyPickup"
	pickup.pickup_id = "courtyard_brass_key"
	pickup.item_definition = BRASS_KEY
	pickup.position = Vector3(2, 0.7, 12)
	add_child(pickup)
	LabTraversalCourse.sign_at(self, "KEY TEST\nE: take key", Vector3(2, 2.5, 12))
	gate = LabGate.new()
	gate.name = "InventoryGate"
	gate.required_item = BRASS_KEY.item_id
	gate.position = Vector3(13, 0, 9)
	add_child(gate)
	LabTraversalCourse.sign_at(self, "LOCK TEST\nE: use brass key", Vector3(13, 3.2, 9))

func build_action_fixture() -> void:
	action_target = LabActionTarget.new()
	action_target.name = "SyntheticWhipAndPistolTarget"
	action_target.position = Vector3(-3.0, 0.9, 3.0)
	add_child(action_target)
	LabTraversalCourse.sign_at(self, "ACTION TEST\nQ: whip / LMB: shoot", Vector3(-3.0, 2.8, 3.0))

func progress_snapshot() -> Dictionary:
	return {"inventory": inventory.to_save_data(), "collected_pickups": [pickup.pickup_id] if pickup.collected else [], "gate_open": gate.is_open}

func restore_progress(progress: Dictionary) -> bool:
	# Call only after LabSaveStore.validate; inventory still validates item IDs/caps.
	var counts: Dictionary = progress.get("inventory", {})
	if not inventory.restore_save_data(counts):
		return false
	pickup.set_collected(pickup.pickup_id in progress.get("collected_pickups", []))
	gate.set_open(bool(progress.get("gate_open", false)))
	return true

func _checkpoint_entered(body: Node3D) -> void:
	if body != player:
		return
	checkpoint = Vector3(-5, 0.2, -6)
	var result := persist_checkpoint()
	message = "Checkpoint saved. R / LOAD restores it." if result == OK else "Checkpoint active; save failed: %s" % error_string(result)

func persist_checkpoint() -> Error:
	return LabSaveStore.write(LabSaveStore.encode(checkpoint, player.avatar.rotation.y, beacon_active, progress_snapshot()), save_path)

func interact() -> bool:
	if pickup.in_reach(player):
		if pickup.try_collect(player, inventory):
			message = "Brass key collected (synthetic demo item)."
			persist_checkpoint()
			return true
		message = "Inventory full; unable to collect."
		return false
	if gate.in_reach(player) and not gate.is_open:
		if gate.try_unlock(player, inventory):
			message = "Test gate unlocked using one brass key."
			persist_checkpoint()
			return true
		message = "Gate requires one brass key."
		return false
	if player.global_position.distance_to(beacon_position) > 2.5:
		message = "Approach the amber beacon, then press E / USE."
		return false
	beacon_active = not beacon_active
	update_beacon()
	var result := persist_checkpoint()
	message = "Beacon %s. Checkpoint state saved." % ("activated" if beacon_active else "deactivated") if result == OK else "Beacon changed; save failed."
	return true

func update_beacon() -> void:
	beacon.material_override = material(Color("9bd891") if beacon_active else Color("e6a840"), true)

func restore_checkpoint() -> bool:
	var data := LabSaveStore.read(save_path)
	if data.is_empty():
		message = "No valid checkpoint file. Enter the cyan pad first."
		return false
	# Older v0.4 saves do not have a progress field; migrate to an empty inventory.
	var progress: Dictionary = data.get("progress", {"inventory": {}, "collected_pickups": [], "gate_open": false})
	if not restore_progress(progress):
		message = "Save contains an unsupported inventory item."
		return false
	var coordinates: Array = data["position"]
	checkpoint = Vector3(coordinates[0], coordinates[1], coordinates[2])
	beacon_active = data["beacon"]
	player.teleport(checkpoint, data["yaw"])
	update_beacon()
	message = "Checkpoint restored."
	return true

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	left_bar = ColorRect.new()
	right_bar = ColorRect.new()
	for bar in [left_bar, right_bar]:
		bar.color = Color.BLACK
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		layer.add_child(bar)
	var panel := PanelContainer.new()
	panel.position = Vector2(20, 18)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.045, 0.06, 0.88)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", style)
	layer.add_child(panel)
	var column := VBoxContainer.new()
	panel.add_child(column)
	var title := Label.new()
	title.text = "NATIVE CHARACTER LABORATORY  /  0.6"
	title.add_theme_color_override("font_color", Color("ecd4aa"))
	title.add_theme_font_size_override("font_size", 20)
	column.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Independent character · Provisional movement · Forward+ / Jolt"
	subtitle.add_theme_font_size_override("font_size", 14)
	column.add_child(subtitle)
	status = Label.new()
	status.add_theme_font_size_override("font_size", 14)
	column.add_child(status)
	notice = Label.new()
	notice.add_theme_font_size_override("font_size", 14)
	column.add_child(notice)
	var controls := Label.new()
	controls.text = "WASD move · Shift run · Space jump/rise · C crouch/dive\nF climb/grab · E use/pickup · Q whip · LMB shoot · RMB aim · H holster\nR load · Tab framing · Mouse look"
	controls.add_theme_font_size_override("font_size", 14)
	column.add_child(controls)
	var credits := Button.new()
	credits.text = "Engine credits / licenses"
	column.add_child(credits)
	var license_dialog := AcceptDialog.new()
	license_dialog.title = "Native Movement Laboratory — credits"
	license_dialog.min_size = Vector2i(650, 420)
	var license_text := TextEdit.new()
	license_text.editable = false
	license_text.custom_minimum_size = Vector2(620, 350)
	license_text.text = "Native Character Laboratory 0.6.0\nIndependently authored primitive assets and gameplay prototype.\nNo original game assets are included. Original behavior is unvalidated.\n\nGodot Engine 4.7.2 — MIT License\n"
	for path in ["res://third_party/godot/LICENSE.txt", "res://third_party/godot/COPYRIGHT.txt"]:
		if FileAccess.file_exists(path):
			license_text.text += "\n" + FileAccess.get_file_as_string(path)
	license_dialog.add_child(license_text)
	layer.add_child(license_dialog)
	credits.pressed.connect(func() -> void:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		touch.release_all()
		touch.set_process_input(false)
		license_dialog.popup_centered()
	)
	license_dialog.visibility_changed.connect(func() -> void:
		if not license_dialog.visible:
			touch.set_process_input(true)
	)
	touch = LabTouchControls.new()
	layer.add_child(touch)
	get_viewport().size_changed.connect(update_framing)
	update_framing()

func update_framing() -> void:
	var dimensions := get_viewport().get_visible_rect().size
	var width := maxf((dimensions.x - dimensions.y * 4.0 / 3.0) / 2.0, 0.0) if original_framing else 0.0
	left_bar.position = Vector2.ZERO
	left_bar.size = Vector2(width, dimensions.y)
	right_bar.position = Vector2(dimensions.x - width, 0)
	right_bar.size = Vector2(width, dimensions.y)

func _physics_process(_delta: float) -> void:
	if Input.is_action_just_pressed(&"interact"):
		interact()
	if Input.is_action_just_pressed(&"restore"):
		restore_checkpoint()
	if Input.is_action_just_pressed(&"presentation"):
		original_framing = not original_framing
		update_framing()
		message = "Original-style 4:3 crop; reference framing unvalidated." if original_framing else "Enhanced widescreen presentation."
	if player.global_position.y < -10:
		player.teleport(checkpoint)
		message = "Returned to checkpoint after leaving test area."
	status.text = "%s | %.2f m/s | PISTOL %d | WHIP %d | KEY %d | GATE %s | %s" % [player.movement_state.to_upper(), Vector2(player.velocity.x, player.velocity.z).length(), player.actions.ammo, player.actions.whip_count, inventory.quantity(BRASS_KEY.item_id), "OPEN" if gate.is_open else "LOCKED", "4:3 CROP" if original_framing else "WIDESCREEN"]
	notice.text = message
