class_name LabActionProfile
extends Resource
## All numbers are test-design parameters. No ROM frame timing has been established.
@export var provenance: String = "PROVISIONAL_NOT_N64_CALIBRATED"
@export var pistol_max_ammo: int = 24
@export var pistol_start_ammo: int = 12
@export var pistol_cooldown_seconds: float = 0.32
@export var pistol_range: float = 32.0
@export var whip_cooldown_seconds: float = 0.72
@export var whip_range: float = 4.1
@export var whip_arc_dot: float = 0.4
@export var aim_walk_multiplier: float = 0.65
@export var pistol_damage: int = 1
