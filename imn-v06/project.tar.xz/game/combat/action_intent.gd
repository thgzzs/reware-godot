class_name LabActionIntent
extends RefCounted
## Captured on the fixed Godot/Jolt physics tick, independent of presentation FPS.
var aim: bool = false
var fire: bool = false
var whip: bool = false
var toggle_weapon: bool = false
static func from_actions() -> LabActionIntent:
	var value := LabActionIntent.new()
	value.aim = Input.is_action_pressed(&"aim")
	value.fire = Input.is_action_pressed(&"fire")
	value.whip = Input.is_action_just_pressed(&"whip")
	value.toggle_weapon = Input.is_action_just_pressed(&"toggle_weapon")
	return value
