class_name LabActionController
extends RefCounted
## Independent behavior-authored third-person pistol/whip LAB, NOT N64 reconstruction.
## Ray collision queries are served by the project's built-in Jolt PhysicsServer3D.
signal action_event(kind: StringName, target: Object)

var profile: LabActionProfile = preload("res://resources/behavior_profiles/action_profile.tres")
var equipped: bool = true
var ammo: int = 12
var shot_cooldown: float = 0.0
var whip_cooldown: float = 0.0
var shot_count: int = 0
var whip_count: int = 0
var last_event: StringName = &"idle"

func reset() -> void:
	equipped = true
	ammo = profile.pistol_start_ammo
	shot_cooldown = 0.0
	whip_cooldown = 0.0
	shot_count = 0
	whip_count = 0
	last_event = &"idle"

func tick(delta: float, intent: LabActionIntent, body: CharacterBody3D, forward: Vector3, blocked: bool) -> void:
	shot_cooldown = maxf(shot_cooldown - delta, 0.0)
	whip_cooldown = maxf(whip_cooldown - delta, 0.0)
	last_event = &"idle"
	if intent.toggle_weapon:
		equipped = not equipped
		last_event = &"holster" if not equipped else &"draw"
	if blocked:
		return
	if intent.whip:
		whip(body, forward)
	elif intent.fire and equipped:
		shoot(body, forward)

func shoot(body: CharacterBody3D, forward: Vector3) -> bool:
	if shot_cooldown > 0.0 or not equipped:
		return false
	if ammo <= 0:
		last_event = &"empty"
		return false
	ammo -= 1
	shot_count += 1
	shot_cooldown = profile.pistol_cooldown_seconds
	last_event = &"shot"
	var target := _ray_target(body, forward, profile.pistol_range)
	if target != null and target.has_method("receive_hit"):
		target.receive_hit(profile.pistol_damage)
		action_event.emit(&"shot_hit", target)
	else:
		action_event.emit(&"shot", target)
	return true

func whip(body: CharacterBody3D, forward: Vector3) -> bool:
	if whip_cooldown > 0.0:
		return false
	whip_count += 1
	whip_cooldown = profile.whip_cooldown_seconds
	last_event = &"whip"
	var target := _ray_target(body, forward, profile.whip_range)
	if target != null and target.has_method("whip_activate"):
		var center: Vector3 = target.global_position - (body.global_position + Vector3.UP)
		if center.length_squared() > 0.0001 and forward.normalized().dot(center.normalized()) >= profile.whip_arc_dot:
			target.whip_activate()
			action_event.emit(&"whip_hit", target)
			return true
	action_event.emit(&"whip", target)
	return true

func _ray_target(body: CharacterBody3D, forward: Vector3, reach: float) -> Object:
	var direction := forward.normalized()
	if direction.is_zero_approx():
		return null
	var origin := body.global_position + Vector3.UP * 1.2
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * reach)
	query.exclude = [body.get_rid()]
	query.collide_with_areas = true
	var hit := body.get_world_3d().direct_space_state.intersect_ray(query)
	return hit.get("collider", null)

func add_ammo(amount: int) -> bool:
	if amount <= 0 or ammo > profile.pistol_max_ammo - amount:
		return false
	ammo += amount
	return true

func save_data() -> Dictionary:
	return {"equipped": equipped, "ammo": ammo}

func restore_data(data: Dictionary) -> bool:
	if not data.has("equipped") or typeof(data["equipped"]) != TYPE_BOOL:
		return false
	if not data.has("ammo") or typeof(data["ammo"]) not in [TYPE_INT, TYPE_FLOAT]:
		return false
	var value: float = float(data["ammo"])
	if not is_finite(value) or value != floorf(value) or value < 0.0 or value > float(profile.pistol_max_ammo):
		return false
	equipped = data["equipped"]
	ammo = int(value)
	shot_cooldown = 0.0
	whip_cooldown = 0.0
	return true
