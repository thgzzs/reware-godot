class_name LabTouchControls
extends Control

signal look_dragged(delta: Vector2)
var enabled: bool = false
var fingers: Dictionary = {}
var held: Dictionary = {}
var joystick_origin: Vector2
var joystick_position: Vector2
var joystick_finger: int = -1
var camera_finger: int = -1
const MOVEMENT: Array[StringName] = [&"move_left", &"move_right", &"move_forward", &"move_back"]
const BUTTONS: Array[StringName] = [&"jump", &"run", &"interact", &"restore", &"crouch", &"traverse", &"fire", &"whip"]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	enabled = OS.has_feature("android") or DisplayServer.is_touchscreen_available()
	visible = enabled

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		release_all()

func _exit_tree() -> void:
	release_all()

func button_center(index: int) -> Vector2:
	var dimensions := get_viewport_rect().size
	var spacing := clampf(dimensions.y * 0.13, 54.0, 96.0)
	return dimensions - Vector2(70.0 + float(index % 2) * spacing, 70.0 + float(index / 2) * spacing)

func _input(event: InputEvent) -> void:
	if not enabled:
		return
	if event is InputEventScreenTouch:
		if not event.pressed:
			release_finger(event.index)
			return
		for index in BUTTONS.size():
			if event.position.distance_to(button_center(index)) < 37.0:
				fingers[event.index] = BUTTONS[index]
				set_action(BUTTONS[index], 1.0)
				return
		if event.position.x < get_viewport_rect().size.x * 0.45 and joystick_finger == -1:
			joystick_finger = event.index
			joystick_origin = event.position
			joystick_position = event.position
		elif camera_finger == -1:
			camera_finger = event.index
		queue_redraw()
	elif event is InputEventScreenDrag:
		if event.index == joystick_finger:
			joystick_position = event.position
			var direction := ((joystick_position - joystick_origin) / 70.0).limit_length()
			set_action(&"move_left", maxf(-direction.x, 0.0))
			set_action(&"move_right", maxf(direction.x, 0.0))
			set_action(&"move_forward", maxf(-direction.y, 0.0))
			set_action(&"move_back", maxf(direction.y, 0.0))
			queue_redraw()
		elif event.index == camera_finger:
			look_dragged.emit(event.relative * 0.004)

func set_action(action: StringName, strength: float) -> void:
	if strength > 0.01:
		held[action] = strength
		Input.action_press(action, strength)
	else:
		Input.action_release(action)
		held.erase(action)

func release_finger(index: int) -> void:
	if fingers.has(index):
		var action: StringName = fingers[index]
		fingers.erase(index)
		if not fingers.values().has(action):
			set_action(action, 0.0)
	if index == joystick_finger:
		joystick_finger = -1
		for action in MOVEMENT:
			set_action(action, 0.0)
	if index == camera_finger:
		camera_finger = -1
	queue_redraw()

func release_all() -> void:
	for action: StringName in held.keys():
		Input.action_release(action)
	held.clear()
	fingers.clear()
	joystick_finger = -1
	camera_finger = -1
	queue_redraw()

func _draw() -> void:
	if not enabled:
		return
	var font := ThemeDB.fallback_font
	for index in BUTTONS.size():
		var center := button_center(index)
		draw_circle(center, 34, Color(0.09, 0.13, 0.16, 0.7))
		draw_arc(center, 34, 0, TAU, 32, Color(0.66, 0.75, 0.74, 0.8), 2)
		var caption: String = ["JUMP", "RUN", "USE", "LOAD", "DUCK", "CLIMB", "FIRE", "WHIP"][index]
		draw_string(font, center + Vector2(-23, 5), caption, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color.WHITE)
	var center := joystick_origin if joystick_finger >= 0 else Vector2(110, get_viewport_rect().size.y - 110)
	draw_circle(center, 68, Color(0.09, 0.13, 0.16, 0.4))
	var knob := center + (joystick_position - center).limit_length(55.0) if joystick_finger >= 0 else center
	draw_circle(knob, 24, Color(0.75, 0.81, 0.78, 0.55))
