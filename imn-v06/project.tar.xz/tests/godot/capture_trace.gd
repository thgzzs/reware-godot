extends SceneTree
## Native-only synthetic trace. It is never presented as original-game reference data.
var lab: LabWorld
var samples: Array[Dictionary] = []
var input_receipts: Array[Dictionary] = []

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	lab = LabWorld.new()
	lab.save_path = "user://trace_checkpoint.json"
	root.add_child(lab)
	lab.player.input_enabled = false
	lab.player.teleport(Vector3(0, 0.2, 12))
	for _settle in 60:
		await physics_frame
	await process_frame
	for tick in 241:
		lab.player.test_input = Vector2.RIGHT if tick >= 30 and tick < 120 else Vector2.ZERO
		lab.player.test_running = tick >= 90
		lab.player.test_jump = tick == 145
		input_receipts.append({"tick": tick, "move": [lab.player.test_input.x, lab.player.test_input.y], "run": lab.player.test_running, "jump": lab.player.test_jump})
		await physics_frame
		await process_frame
		var position := lab.player.position
		var velocity := lab.player.velocity
		var camera := lab.player.orbit.camera.global_position
		var orientation := lab.player.global_basis.get_rotation_quaternion()
		samples.append({"tick": tick, "time": float(tick) / 60.0, "position": [position.x, position.y, position.z], "velocity": [velocity.x, velocity.y, velocity.z], "rotation": [orientation.x, orientation.y, orientation.z, orientation.w], "state": lab.player.movement_state, "camera_position": [camera.x, camera.y, camera.z], "beacon_active": lab.beacon_active})
	var destination := "res://reports/native_trace_v0.3.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--trace-output="):
			destination = argument.trim_prefix("--trace-output=")
	var file := FileAccess.open(destination, FileAccess.WRITE)
	if file == null:
		push_error("Cannot open trace output: " + destination)
		quit(1)
		return
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(JSON.stringify(input_receipts).to_utf8_buffer())
	var digest := context.finish().hex_encode()
	file.store_string(JSON.stringify({"schema": 1, "source": "native_provisional_synthetic", "provenance": {"kind": "native_provisional_synthetic", "evidence": "res://tests/godot/capture_trace.gd scripted test plan; no original-game reference"}, "scenario": "native_lab_synthetic_movement", "coordinate_frame": "godot_y_up_native_lab", "input_receipt_sha256": digest, "input_receipt_encoding": "UTF-8 Godot JSON.stringify(input_receipts), compact sorted keys", "input_receipts": input_receipts, "reference_game": false, "tick_hz": 60, "units": {"position": "metres", "velocity": "metres_per_second", "time": "seconds"}, "samples": samples}, "\t"))
	file.close()
	print("NATIVE_TRACE_WRITTEN samples=", samples.size(), " path=", destination)
	lab.queue_free()
	await process_frame
	quit()
