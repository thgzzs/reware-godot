extends SceneTree
## Synthetic fixed-tick capture, never original-game evidence.
class Recorder extends Node:
	signal finished
	var player: LabPlayer
	var warmup: int = 60
	var tick: int = 0
	var samples: Array[Dictionary] = []
	var receipts: Array[Dictionary] = []
	func _ready() -> void:
		process_physics_priority = 100
	func apply_intent(index: int) -> void:
		player.test_input = Vector2.RIGHT if index >= 30 and index < 120 else Vector2.ZERO
		player.test_running = index >= 90
		player.test_jump = index == 145
		player.test_jump_held = false
		player.test_crouch = false
		player.test_traverse = false
	func _physics_process(_delta: float) -> void:
		if warmup > 0:
			warmup -= 1
			if warmup == 0:
				apply_intent(0)
			return
		var p := player.global_position
		var v := player.velocity
		samples.append({"tick": tick, "time": float(tick) / 60.0, "position": [p.x, p.y, p.z], "velocity": [v.x, v.y, v.z], "state": player.movement_state})
		receipts.append({"tick": tick, "right": tick >= 30 and tick < 120, "run": tick >= 90, "jump": tick == 145})
		tick += 1
		if tick >= 241:
			set_physics_process(false)
			finished.emit()
		else:
			apply_intent(tick)

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	var lab := LabWorld.new()
	lab.save_path = "user://fixed_tick_capture.json"
	root.add_child(lab)
	lab.player.input_enabled = false
	lab.player.teleport(Vector3(0, 0.2, 12))
	var recorder := Recorder.new()
	recorder.player = lab.player
	root.add_child(recorder)
	await recorder.finished
	var output := "res://reports/fixed_tick_trace_v0.4.json"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--trace-output="):
			output = argument.trim_prefix("--trace-output=")
	var hash_context := HashingContext.new()
	hash_context.start(HashingContext.HASH_SHA256)
	hash_context.update(JSON.stringify(recorder.receipts).to_utf8_buffer())
	var file := FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		quit(1)
		return
	file.store_string(JSON.stringify({"schema": 1, "scenario": "native_fixed_tick_render_rate_check", "coordinate_frame": "godot_y_up_native_lab", "tick_hz": 60, "reference_game": false, "units": {"position": "metres", "velocity": "metres_per_second", "time": "seconds"}, "provenance": {"kind": "native_provisional_synthetic", "evidence": "tests/godot/fixed_tick_capture.gd"}, "sampling": "Physics priority100 after player, one intent per physics tick", "input_receipt_sha256": hash_context.finish().hex_encode(), "input_receipts": recorder.receipts, "samples": recorder.samples}, "\t"))
	file.close()
	print("FIXED_TICK_CAPTURE samples=", recorder.samples.size(), " output=", output)
	lab.queue_free()
	recorder.queue_free()
	await process_frame
	quit(0)
