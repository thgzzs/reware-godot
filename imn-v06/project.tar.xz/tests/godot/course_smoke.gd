extends SceneTree
var lab: LabWorld
var checks: Array[String] = []
var failures: Array[String] = []

func _initialize() -> void:
	call_deferred("run")

func frames(count: int) -> void:
	for _tick in count:
		await physics_frame
	await process_frame

func check(condition: bool, caption: String) -> void:
	checks.append(caption)
	if not condition:
		failures.append(caption)
		push_error("COURSE_FAIL: " + caption)

func run() -> void:
	lab = LabWorld.new()
	lab.save_path = "user://course_smoke.json"
	root.add_child(lab)
	lab.player.input_enabled = false
	await frames(5)
	check(InputMap.has_action(&"crouch") and InputMap.has_action(&"traverse"), "Shared traversal actions installed")
	lab.touch.enabled = true
	for index in [4, 5]:
		var event := InputEventScreenTouch.new()
		event.index = index
		event.position = lab.touch.button_center(index)
		event.pressed = true
		lab.touch._input(event)
	check(Input.is_action_pressed(&"crouch") and Input.is_action_pressed(&"traverse"), "New touch buttons press shared actions")
	lab.touch._notification(Node.NOTIFICATION_APPLICATION_PAUSED)
	check(not Input.is_action_pressed(&"crouch") and not Input.is_action_pressed(&"traverse"), "Pause releases traversal actions")
	lab.player.teleport(Vector3(-14, 0.03, -6.7))
	await frames(10)
	lab.player.test_traverse = true
	await frames(3)
	check(lab.player.movement_state == &"climbing", "Playable ladder attaches")
	lab.player.test_input = Vector2.UP
	await frames(145)
	check(lab.player.position.y > 3.4 and lab.player.compatibility.climbing == null, "Playable ladder exits onto upper landing")
	lab.player.test_input = Vector2.ZERO
	lab.player.teleport(Vector3(12, 0.03, -2.4))
	await frames(10)
	lab.player.test_traverse = true
	await frames(3)
	check(lab.player.movement_state == &"ledge_hang", "Playable ledge permits hanging")
	lab.player.test_jump = true
	await frames(55)
	check(lab.player.position.y > 1.7 and lab.player.is_on_floor(), "Playable ledge mantle lands")
	lab.player.teleport(Vector3(0, -1.7, -10))
	await frames(15)
	check(lab.player.movement_state == &"swimming", "Playable pool registers entry")
	lab.player.test_jump_held = true
	await frames(100)
	check(lab.player.position.y < -0.95 and lab.player.position.y > -1.25, "Playable pool ascent stops at surface")
	lab.player.test_jump_held = false
	lab.player.teleport(Vector3(0, -1.1, -7.5), PI)
	await frames(5)
	lab.player.test_traverse = true
	await frames(3)
	check(lab.player.movement_state == &"ledge_hang", "Playable pool permits exit grab")
	lab.player.test_jump = true
	await frames(60)
	check(lab.player.position.y > -0.1 and lab.player.is_on_floor(), "Playable pool climb-out returns to dry ground")
	lab.player.teleport(Vector3(0, 0.03, 4.1))
	lab.player.test_crouch = true
	lab.player.test_input = Vector2.UP
	await frames(100)
	check(lab.player.position.z < 2.0 and lab.player.compatibility.crouched, "Low passage permits crouched travel")
	lab.player.test_input = Vector2.ZERO
	lab.player.test_crouch = false
	await frames(5)
	check(lab.player.compatibility.crouched, "Low roof blocks standing overlap")
	var file := FileAccess.open("res://reports/course_integration_v0.4.json", FileAccess.WRITE)
	var report := {"schema": 1, "release": "0.4.0", "kind": "native_playable_course_integration", "checks": checks, "check_count": checks.size(), "failures": failures, "passed": failures.is_empty(), "reference_comparison": "NOT_PERFORMED"}
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	print(JSON.stringify(report))
	lab.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
