extends SceneTree
func _initialize() -> void:
	for property: Dictionary in ProjectSettings.get_property_list():
		if property.name == "physics/3d/physics_engine":
			print("PHYSICS_PROPERTY ", property)
	print("SERVERCLASS ", ClassDB.class_exists("JoltPhysicsServer3D"))
	print("RENDER_METHOD_EXISTS ", RenderingServer.has_method("get_current_rendering_driver_name"))
	quit()
