extends SceneTree
var main: Node3D

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	main = load("res://game/bootstrap/main.tscn").instantiate()
	root.add_child(main)
	for _index in 90:
		await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	var output := "res://reports/native_lab_v0.3.png"
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--screenshot="):
			output = argument.trim_prefix("--screenshot=")
	var result := image.save_png(output)
	print("RENDER_PROBE result=", result, " method=", RenderingServer.get_current_rendering_method(), " output=", output)
	quit(0 if result == OK else 1)
