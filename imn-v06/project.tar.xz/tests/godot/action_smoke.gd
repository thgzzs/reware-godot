extends SceneTree
## No N64 behavior is asserted. Test operates against real Godot 3D physics.
var failures: Array[String] = []
var checks: int = 0
func _initialize() -> void:
	call_deferred("run")
func check(condition: bool, name: String) -> void:
	checks += 1
	if not condition:
		failures.append(name)
		push_error("ACTION_TEST_FAILED: " + name)
func run() -> void:
	var parent := Node3D.new()
	root.add_child(parent)
	var body := CharacterBody3D.new()
	parent.add_child(body)
	body.position = Vector3.ZERO
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.3
	capsule.height = 1.7
	shape.shape = capsule
	shape.position.y = 0.85
	body.add_child(shape)
	var target := LabActionTarget.new()
	target.position = Vector3(0, 0.9, -3.0)
	parent.add_child(target)
	await physics_frame
	await physics_frame
	var actions := LabActionController.new()
	check(actions.ammo == actions.profile.pistol_start_ammo, "Pistol starts with declared provisional ammo")
	check(actions.shoot(body, Vector3.FORWARD), "Pistol can shoot when loaded")
	check(target.health == 2, "Pistol ray hits target using 3D physics")
	check(actions.ammo == 11, "Each shot consumes exactly one round")
	check(not actions.shoot(body, Vector3.FORWARD), "Pistol obeys fixed-tick cooldown")
	var none := LabActionIntent.new()
	actions.tick(actions.profile.pistol_cooldown_seconds, none, body, Vector3.FORWARD, true)
	check(actions.shoot(body, Vector3.FORWARD) and target.health == 1, "Cooldown permits next shot")
	check(actions.whip(body, Vector3.FORWARD) and target.whip_switch, "Whip activates synthetic trigger")
	check(not actions.whip(body, Vector3.FORWARD), "Whip cooldown prevents repeated activation")
	var saved := actions.save_data()
	check(actions.restore_data(JSON.parse_string(JSON.stringify(saved))), "Action save survives JSON numeric round-trip")
	check(not actions.restore_data({"equipped": true, "ammo": 2.5}), "Fractional ammo is rejected")
	check(not actions.restore_data({"equipped": true, "ammo": -1}), "Negative ammo is rejected")
	check(not actions.add_ammo(-1), "Negative ammo grant is rejected")
	actions.reset()
	check(actions.ammo == actions.profile.pistol_start_ammo and actions.whip_count == 0, "Reset clears transient state")
	parent.queue_free()
	await process_frame
	var report := {"release": "0.6.0", "kind": "synthetic_combat_Jolt", "checks": checks, "failures": failures, "passed": failures.is_empty(), "reference_samples": 0}
	print(JSON.stringify(report))
	quit(0 if failures.is_empty() else 1)
