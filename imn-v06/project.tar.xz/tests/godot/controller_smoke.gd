extends SceneTree
## Synthetic fixtures verify the new controller only, never original-game equivalence.
var scene: Node3D
var player: LabPlayer
var checks: Array[String] = []
var failures: Array[String] = []
var measurements: Dictionary = {}

func _initialize() -> void:
	call_deferred("run")
func check(condition: bool, caption: String) -> void:
	checks.append(caption)
	if not condition:
		failures.append(caption)
		push_error("CONTROLLER_FAIL: " + caption)
func frames(count: int) -> void:
	for _tick in count: await physics_frame
	await process_frame
func box(center: Vector3, size: Vector3, rotation_z: float = 0.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.rotation.z = rotation_z
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	body.add_child(collision)
	scene.add_child(body)
	return body
func reset_scene(floor_y: float = 0.0) -> void:
	if scene != null:
		scene.queue_free()
		await process_frame
	scene = Node3D.new()
	root.add_child(scene)
	box(Vector3(0, floor_y - 0.5, 0), Vector3(50, 1, 50))
	player = LabPlayer.new()
	player.position = Vector3(0, floor_y + 0.05, 0)
	scene.add_child(player)
	player.input_enabled = false
	await frames(20)
func ledge_fixture() -> StaticBody3D:
	var ledge := box(Vector3(0, 1, -2), Vector3(4, 2, 2))
	player.teleport(Vector3(0, 0.03, -0.35))
	await frames(5)
	player.test_traverse = true
	await frames(3)
	return ledge
func zone_shape(area: Area3D, size: Vector3) -> void:
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	collision.shape = shape
	area.add_child(collision)
	scene.add_child(area)

func run() -> void:
	LabActions.install()
	await reset_scene()
	check(player.avatar.joints.size() == 11 and player.avatar.animation_player.has_animation(&"walking"), "Original eleven-joint avatar has AnimationPlayer clips")
	player.test_input = Vector2.RIGHT
	await frames(100)
	check(absf(player.velocity.x - player.profile.walk_speed) < 0.02, "Walking preserves provisional profile speed")
	check(player.avatar.active_state == &"walking", "Walking state selects animation")
	var limb_before: Vector3 = player.avatar.joints.LeftArm.rotation
	await frames(10)
	check(player.avatar.joints.LeftArm.rotation.distance_to(limb_before) > 0.01, "Walking clip actually animates limb transforms")
	player.test_input = Vector2.ZERO
	player.test_crouch = true
	await frames(15)
	check(player.compatibility.crouched and absf((player.capsule_collision.shape as CapsuleShape3D).height - 1.0) < 0.01, "Crouching resizes the actual Jolt capsule")
	check(player.movement_state == &"crouching", "Crouching state selects")
	var ceiling := box(player.position + Vector3(0, 1.35, 0), Vector3(2, 0.3, 2))
	await frames(3)
	player.test_crouch = false
	await frames(5)
	check(player.compatibility.crouched, "Blocked overhead clearance retains crouch")
	ceiling.queue_free()
	await frames(5)
	check(not player.compatibility.crouched, "Cleared overhead permits standing capsule")

	await reset_scene()
	box(Vector3(2, 0.12, 0), Vector3(1.5, 0.24, 3))
	player.test_input = Vector2.RIGHT
	var peak := 0.0
	for _tick in 85:
		await physics_frame
		peak = maxf(peak, player.position.y)
	await process_frame
	measurements.step_peak = peak
	check(peak > 0.2 and player.position.x > 3.0, "Step resolver ascends and traverses a0.24m step")
	await reset_scene()
	box(Vector3(2, 0.45, 0), Vector3(1.5, 0.9, 3))
	player.test_input = Vector2.RIGHT
	await frames(100)
	check(player.position.x < 1.0 and player.position.y < 0.1, "Too-high step blocks instead of teleporting")

	await reset_scene()
	await ledge_fixture()
	check(player.movement_state == &"ledge_hang", "Jolt wall/top/clearance probes attach reachable ledge")
	var hang_x := player.position.x
	player.test_input = Vector2.RIGHT
	await frames(20)
	check(player.movement_state == &"ledge_shimmy" and absf(player.position.x - hang_x) > 0.2, "Shimmy follows neighboring supported ledge")
	player.test_input = Vector2.ZERO
	player.test_jump = true
	await frames(60)
	measurements.mantle_position = str(player.position)
	check(player.position.y > 1.9 and player.is_on_floor(), "Mantle climbs then lands on Jolt support")

	await reset_scene()
	await ledge_fixture()
	var landing: Vector3 = player.compatibility.ledge.get("landing", Vector3(0, 2, -1.4))
	box(landing + Vector3(0, 1.4, 0), Vector3(3, 0.4, 3))
	await frames(3)
	player.test_jump = true
	await frames(35)
	check(not player.compatibility.mantling and player.position.y < 1.0, "Dynamic overhead obstruction prevents mantle embedding")
	await reset_scene()
	var support := await ledge_fixture()
	support.queue_free()
	await frames(30)
	check(player.compatibility.ledge.is_empty() and player.position.y < 0.3, "Removed support releases hanging character")
	await reset_scene()
	box(Vector3(0, 1, -2), Vector3(4, 2, 2))
	box(Vector3(0, 3.35, -2), Vector3(4, 0.4, 2))
	player.teleport(Vector3(0, 0.03, -0.35))
	await frames(3)
	player.test_traverse = true
	await frames(5)
	check(player.compatibility.ledge.is_empty(), "Blocked top clearance rejects attachment")
	await reset_scene()
	await ledge_fixture()
	player.test_crouch = true
	await frames(50)
	check(player.compatibility.ledge.is_empty() and player.position.y < 0.2, "Crouch drops ledge into Jolt fall and landing")

	await reset_scene()
	box(Vector3(0, 1.5, -1.0), Vector3(3, 3, 0.6))
	box(Vector3(0, 2.8, -2), Vector3(3, 0.4, 2))
	var ladder := LabClimbZone.new()
	ladder.position = Vector3(0, 1.5, -0.1)
	ladder.bottom_y = 0
	ladder.top_y = 3
	ladder.climb_anchor = Vector3(0, 0, -0.1)
	zone_shape(ladder, Vector3(2, 4, 1.2))
	await frames(5)
	player.test_traverse = true
	player.test_input = Vector2.UP
	await frames(60)
	check(player.movement_state == &"climbing" and player.position.y > 1.4, "Authored ladder attaches and ascends at fixed tick")
	player.test_jump = true
	player.test_input = Vector2.ZERO
	await frames(5)
	check(player.compatibility.climbing == null and player.velocity.z > 0.5, "Jump detaches ladder away from wall")
	player.teleport(Vector3(0, 0.03, -0.1))
	await frames(5)
	player.test_traverse = true
	player.test_input = Vector2.UP
	await frames(140)
	check(player.compatibility.climbing == null and player.position.y > 2.9, "Ladder top exits only onto clear supported landing")

	await reset_scene(-4)
	var water := LabWaterZone.new()
	water.surface_y = 0
	water.position = Vector3(0, -2, 0)
	zone_shape(water, Vector3(10, 4, 10))
	player.teleport(Vector3(0, -2, 0))
	await frames(10)
	check(player.movement_state == &"swimming", "Water volume switches character to swimming")
	player.test_jump_held = true
	await frames(100)
	check(absf(player.position.y + player.profile.swim_surface_offset) < 0.05, "Swimming ascent respects authored surface limit")
	player.test_jump_held = false
	player.test_crouch = true
	var surface := player.position.y
	await frames(90)
	check(player.position.y < surface - 0.5, "Swimming descend moves down after acceleration reversal")
	player.test_crouch = false
	player.teleport(Vector3(0, -2, 0))
	await frames(5)
	check(player.movement_state == &"swimming", "Teleport inside existing water refreshes area membership")
	player.teleport(Vector3(7, -3.9, 0))
	await frames(10)
	check(player.movement_state != &"swimming", "Leaving water returns to dry movement")
	box(Vector3(0, -0.5, -6), Vector3(6, 1, 2))
	player.teleport(Vector3(0, -1.1, -4.4))
	await frames(3)
	player.test_traverse = true
	await frames(3)
	check(player.movement_state == &"ledge_hang", "Swimming traverse can grab a dry pool edge")
	player.test_jump = true
	await frames(60)
	check(player.position.y > -0.1 and player.is_on_floor(), "Water does not cancel climb-out mantle onto dry support")

	await reset_scene()
	var rigid := RigidBody3D.new()
	rigid.position = Vector3(1.4, 0.5, 0)
	rigid.mass = 4
	rigid.lock_rotation = true
	_add_rigid(rigid)
	player.test_input = Vector2.RIGHT
	await frames(130)
	measurements.pushed_rigid_x = rigid.position.x
	measurements.pushed_rigid_velocity = str(rigid.linear_velocity)
	measurements.push_player_position = str(player.position)
	check(rigid.position.x > 1.75, "Intended character velocity pushes a real Jolt rigid body")

	await reset_scene()
	box(Vector3(0, 2.4, 0), Vector3(8, 0.3, 4), deg_to_rad(60))
	player.teleport(Vector3(0, 3.4, 0))
	var slope_states: Dictionary = {}
	for _tick in 90:
		await physics_frame
		slope_states[player.movement_state] = true
	await process_frame
	check(slope_states.has(&"sliding") and player.position.x < -0.5, "Steep Jolt contact enters sliding and moves downhill")

	await reset_scene()
	var platform := AnimatableBody3D.new()
	platform.position = Vector3(0, 0.4, 0)
	platform.sync_to_physics = false
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(4, 0.4, 4)
	collision.shape = shape
	platform.add_child(collision)
	scene.add_child(platform)
	player.teleport(Vector3(0, 0.65, 0))
	await frames(20)
	var ride_start := player.position.x
	for _tick in 50:
		platform.position.x += 0.02
		await physics_frame
	await process_frame
	check(player.position.x - ride_start > 0.65 and player.is_on_floor(), "Character rides actual Jolt moving platform")
	player.test_jump = true
	for _tick in 4:
		platform.position.x += 0.02
		await physics_frame
	await process_frame
	measurements.platform_jump_velocity = str(player.velocity)
	check(player.velocity.y > 1.0 and player.velocity.x > 0.3, "Jump inherits moving support horizontal velocity once")
	player.test_crouch = true
	await frames(2)
	player.teleport(Vector3(10, 0.05, 0))
	check(not player.compatibility.crouched and player.compatibility.climbing == null and player.compatibility.ledge.is_empty(), "Teleport resets traversal and crouch state")
	var report := {"schema": 1, "release": "0.4.0", "kind": "synthetic_native_controller_jolt_fixtures", "engine": Engine.get_version_info().string, "checks": checks, "check_count": checks.size(), "failures": failures, "measurements_lab_only": measurements, "passed": failures.is_empty(), "reference_comparison": "NOT_PERFORMED"}
	var output := FileAccess.open("res://reports/controller_integration_v0.4.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(report, "\t"))
	output.close()
	print(JSON.stringify(report))
	scene.queue_free()
	await process_frame
	quit(0 if failures.is_empty() else 1)
func _add_rigid(body: RigidBody3D) -> void:
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3.ONE
	collision.shape = shape
	body.add_child(collision)
	scene.add_child(body)
