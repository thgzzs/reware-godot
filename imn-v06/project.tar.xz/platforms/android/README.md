# Android ARM64 build

Requires Linux x86-64, Python 3, OpenJDK 17 and acceptance of the relevant Android SDK licenses. Tools are downloaded only from official Godot/GitHub and Google locations. No ROM is needed to build the independently authored test laboratory.

From the project directory:

```sh
python3 tools/build/bootstrap_toolchain.py ../toolchain
bash platforms/android/export_debug.sh
```

The script pins Godot 4.7.2 stable official ed1daf0bf and all download hashes. The mutable Google `platform-tools-latest` URL fails closed if its bytes change. Update a pin only after separately verifying the new official release. A local OpenJDK 17 installation is required; override `JAVA_HOME` where appropriate. `GODOT_BIN`, `NATIVE_TOOLCHAIN_ROOT`, `ANDROID_HOME`, and `NATIVE_DEBUG_KEYSTORE` support alternate local paths.

The export preset must be `Android Vulkan ARM64`. Forward+ is required; no Mobile/Compatibility fallback is configured. The APK requires Android 10/API29 and Vulkan1.1; those manifest requirements alone do not guarantee all hardware satisfies Forward+ requirements. Unsupported devices must remain unsupported instead of switching renderers.

Godot4.7.2's non-Gradle exporter emits Vulkan feature values with incorrect binary XML types. `normalize_manifest.py` converts the existing Vulkan feature attributes to their Android boolean/integer types, maps `android:version` to its framework resource ID, and raises the existing minimum API to29. It verifies idempotence and unchanged contents for every non-manifest entry. It does not remove or lower the Vulkan requirement. The result is aligned for16KiB pages and debug-signed, then checked with Android build-tools and an original ELF/package verifier.

The disposable debug signing key stays outside the project and is excluded from deliverables. The prior session key was lost when the workspace reset. **This build uses a new certificate; an older prototype with the same package ID must be uninstalled before installation. Uninstalling can erase its local save data.** A repeat build using the same retained `NATIVE_DEBUG_KEYSTORE` keeps its signature identity. Do not use this disposable key for a public release.

Package verification is distinct from device testing. No device was available for this artifact: installation, launch, lifecycle, audio, Bluetooth controls and hardware GPU performance remain untested.
