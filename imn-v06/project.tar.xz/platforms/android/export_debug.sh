#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")/../.." && pwd)"
workspace_root="$(cd "$project_root/.." && pwd)"
toolchain_root="${NATIVE_TOOLCHAIN_ROOT:-$workspace_root/toolchain}"
godot_bin="${GODOT_BIN:-$toolchain_root/godot/Godot_v4.7.2-stable_linux.x86_64}"
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export ANDROID_HOME="${ANDROID_HOME:-$toolchain_root/android}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export XDG_DATA_HOME="$toolchain_root/xdg/data"
export XDG_CONFIG_HOME="$toolchain_root/xdg/config"
export XDG_CACHE_HOME="$toolchain_root/xdg/cache"
export TMPDIR="$toolchain_root/tmp"
build_tools="$ANDROID_HOME/build-tools/35.0.1"
export LD_LIBRARY_PATH="$build_tools/lib64:$JAVA_HOME/lib:$JAVA_HOME/lib/server${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
mkdir -p "$TMPDIR" "$XDG_CONFIG_HOME/godot" "$XDG_CACHE_HOME" "$project_root/builds" "$project_root/reports"
if [[ "$godot_bin" == "$toolchain_root/godot/Godot_v4.7.2-stable_linux.x86_64" ]]; then
    chmod +x "$godot_bin"
fi
chmod +x "$build_tools/aapt" "$build_tools/zipalign"
if [[ "$("$godot_bin" --version)" != '4.7.2.stable.official.ed1daf0bf' ]]; then
    echo 'Expected pinned Godot 4.7.2 stable official ed1daf0bf' >&2
    exit 2
fi
keystore="${NATIVE_DEBUG_KEYSTORE:-$toolchain_root/native-lab-debug.keystore}"
if [[ ! -f "$keystore" ]]; then
    "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$keystore" -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Native Movement Laboratory Debug,O=Independent Prototype,C=US'
fi
cat > "$XDG_CONFIG_HOME/godot/editor_settings-4.7.tres" <<EOF
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$keystore"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOF
apk_output="${1:-$project_root/builds/NativeLab_android_arm64_v0.5.apk}"
python3 "$project_root/tools/build/check_framework.py" "$ANDROID_HOME/platforms/android-35/android.jar" --report "$project_root/reports/android_framework_verification.json"
build_directory="$(mktemp -d "$TMPDIR/android-build.XXXXXX")"
raw_apk="$build_directory/raw.apk"
normalized_apk="$build_directory/normalized.apk"
aligned_apk="$build_directory/aligned.apk"
signed_apk="$build_directory/$(basename "$apk_output")"
check_log() {
    python3 - "$1" <<'PY'
import re, sys
from pathlib import Path
data = Path(sys.argv[1]).read_text()
errors = re.findall(r'(?m)^(?:SCRIPT )?ERROR:.*$', data)
if errors:
    raise SystemExit('Godot reported errors despite its process status:\n' + '\n'.join(errors))
PY
}
"$godot_bin" --headless --path "$project_root" --import 2>&1 | tee "$project_root/reports/android_import.log"
check_log "$project_root/reports/android_import.log"
python3 "$project_root/tools/build/record_build.py" start "$project_root" "$project_root/reports/android_build_receipt.json"
"$godot_bin" --headless --path "$project_root" --export-debug 'Android Vulkan ARM64' "$raw_apk" 2>&1 | tee "$project_root/reports/android_export.log"
check_log "$project_root/reports/android_export.log"
python3 "$project_root/tools/build/normalize_manifest.py" "$raw_apk" "$normalized_apk" --report "$project_root/reports/android_manifest_normalization.json"
"$build_tools/zipalign" -P 16 -f 4 "$normalized_apk" "$aligned_apk"
"$JAVA_HOME/bin/java" -jar "$build_tools/lib/apksigner.jar" sign --ks "$keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$signed_apk" "$aligned_apk"
"$JAVA_HOME/bin/java" -jar "$build_tools/lib/apksigner.jar" verify --verbose --print-certs "$signed_apk" > "$project_root/reports/android_signature.txt"
"$build_tools/zipalign" -P 16 -c -v 4 "$signed_apk" > "$project_root/reports/android_zip_alignment.txt"
"$build_tools/aapt" dump badging "$signed_apk" > "$project_root/reports/android_badging.txt"
python3 "$project_root/tools/build/verify_apk.py" "$signed_apk" --badging "$project_root/reports/android_badging.txt" --report "$project_root/reports/android_package_verification.json"
python3 "$project_root/tools/build/record_build.py" finish "$project_root" "$project_root/reports/android_build_receipt.json" --apk "$signed_apk" --badging "$project_root/reports/android_badging.txt"
mkdir -p "$(dirname "$apk_output")"
python3 - "$signed_apk" "$apk_output" <<'PY'
import os, shutil, sys
source, destination = sys.argv[1:]
pending = destination + '.pending'
shutil.copy2(source, pending)
os.replace(pending, destination)
PY
echo "APK created and package checks passed: $apk_output"
