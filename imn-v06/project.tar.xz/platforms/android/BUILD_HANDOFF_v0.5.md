# Android APK build handoff (v0.5 source)

**Current status: no APK has been generated from this v0.5 source in the current environment.** This document is a reproducible build route, **not** a claim of build success. The previous v0.4 reports are historical only.

## Option A — GitHub Actions (no Android SDK on your computer)

1. Create a **private** GitHub repository and upload the contents of `InfernalMachineNative/` to its root (including the hidden `.github/` directory). **Do not upload your ROM or extracted assets.**
2. In the GitHub repository, go to **Actions** → **Build Android ARM64 Debug APK (Godot 4.7.2)** → **Run workflow**.
3. If the job completes successfully, open that run and download the `NativeLab-Android-ARM64-v0.5.0-debug` workflow artifact. The artifact is a ZIP containing `NativeLab_android_arm64_v0.5.apk`.
4. Consult the `NativeLab-Android-build-reports` artifact for the package validation and logs. The build uses a disposable debug signing key created on the CI runner and does **not** constitute an installation or device gameplay test.

A failed workflow means **do not treat the APK as verified**; review the logs and fix the underlying failure. This path requires network access from GitHub Actions, and its success has **not** been verified from this environment.

## Option B — Networked Ubuntu Linux host

Prerequisites: an Ubuntu 24.04 x86-64 host, Python 3, Java 17 (`JAVA_HOME`), and network access to pinned official Godot and Google SDK archives. Accept relevant Android SDK licenses. From the project root:

```bash
python3 -m unittest discover -s tests/unit -v
python3 -m unittest discover -s tests/regression -v
python3 -m unittest discover -s tests/asset_analysis -v
python3 -m unittest discover -s tools/build -p 'test_*.py' -v
python3 tools/build/bootstrap_toolchain.py ../toolchain
bash platforms/android/export_debug.sh "$PWD/builds/NativeLab_android_arm64_v0.5.apk"
```

The script checks Godot's exact version, imports project files, uses official ARM64 Android export templates, normalizes manifest attribute types without lowering Vulkan requirements, aligns 16-KiB native libraries, debug-signs, validates the archive and records checksums. `godot --headless` gameplay smoke tests should also be run before treating v0.5 as an integration-tested build; the GitHub Actions workflow includes them.

The project is **Forward+ only** and requires built-in Jolt and a compatible Android Vulkan RenderingDevice implementation. It will refuse unsupported devices. Minimum API29/Vulkan1.1 are only necessary gates, not sufficient proof of full compatibility. Android installation, launch, touch input, audio and GPU performance must be tested on an actual compatible device.

**Debug signing warning:** Each clean GitHub Actions workflow run creates a new signing key. Updating an earlier install with a different signature will fail, and uninstalling the earlier version can remove saved data. For reproducible upgrades, manage a secure persistent signing key outside public repositories. No distribution rights are asserted for proprietary N64 content. The APK contains only independent replacement assets and code, not the ROM.
